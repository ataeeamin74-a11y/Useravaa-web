import {
  cancelConversation,
  formatDuration,
  formatPrice,
  getConversationActions,
  getConversationStatusLabel,
  getNextActionText,
  getPersonName,
  getPersonRole,
  type ConversationAction,
  type ConversationFixture
} from "@/features/v51/data/conversations";
import { StateActionButton } from "./StateActionButton";
import styles from "./ConversationCluster.module.css";

type ConversationDetailPanelProps = {
  conversation: ConversationFixture;
  onConversationChange?: (conversation: ConversationFixture) => void;
};

export function ConversationDetailPanel({ conversation, onConversationChange }: ConversationDetailPanelProps) {
  const actions = getConversationActions(conversation);

  const handleAction = (action: ConversationAction) => {
    if (action.kind === "cancel") {
      onConversationChange?.(cancelConversation(conversation));
    }
  };

  return (
    <div className={styles.detailGrid}>
      <section className={styles.panel}>
        <div className={styles.topline}>
          <div className={styles.person}>
            <span className={styles.avatar}>{conversation.direction === "incoming" ? "د" : conversation.profile.initials}</span>
            <div>
              <h2>{getPersonName(conversation)}</h2>
              <p className={styles.role}>{getPersonRole(conversation)}</p>
            </div>
          </div>
          <span className={`${styles.badge} ${styles.badgeAction}`}>{getConversationStatusLabel(conversation)}</span>
        </div>

        <div className={styles.badges}>
          <span className={styles.badge}>{formatDuration(conversation.duration)}</span>
          <span className={styles.badge}>{formatPrice(conversation)}</span>
          <span className={styles.badge}>{conversation.submittedAtLabel}</span>
          {conversation.selectedTime ? (
            <span className={`${styles.badge} ${styles.badgeSoft}`}>
              {conversation.selectedTime.dateLabel}، {conversation.selectedTime.timeLabel}
            </span>
          ) : null}
        </div>

        <p className={styles.infoBox}>{getNextActionText(conversation)}</p>

        <h2>جزئیات درخواست</h2>
        <div className={styles.summaryRows}>
          <div className={styles.summaryRow}>
            <span>مدت گفت‌وگو</span>
            <strong>{formatDuration(conversation.duration)}</strong>
          </div>
          <div className={styles.summaryRow}>
            <span>زمان انتخاب‌شده</span>
            <strong>
              {conversation.selectedTime ? `${conversation.selectedTime.dateLabel}، ${conversation.selectedTime.timeLabel}` : "هنوز انتخاب نشده است"}
            </strong>
          </div>
          <div className={styles.summaryRow}>
            <span>توضیح</span>
            <strong>{conversation.note}</strong>
          </div>
        </div>
      </section>

      <aside className={styles.panel}>
        <h2>اقدام بعدی</h2>
        <div className={styles.actions}>
          {actions.map((action) => (
            <StateActionButton key={action.kind} action={action} onAction={handleAction} />
          ))}
        </div>

        <h2>جریان گفت‌وگو</h2>
        <div className={styles.timeline}>
          <div className={styles.timelineStep}>
            <strong>درخواست ثبت شد</strong>
            <span>درخواست گفت‌وگو ساخته شد.</span>
          </div>
          <div className={styles.timelineStep}>
            <strong>زمان هماهنگ می‌شود</strong>
            <span>ارائه‌دهنده حداقل سه زمان پیشنهاد می‌دهد.</span>
          </div>
          <div className={styles.timelineStep}>
            <strong>نهایی‌سازی</strong>
            <span>بعد از انتخاب زمان، پرداخت انجام می‌شود.</span>
          </div>
          <div className={styles.timelineStep}>
            <strong>گفت‌وگو و بازخورد</strong>
            <span>بعد از گفت‌وگو، بازخورد ثبت می‌شود.</span>
          </div>
        </div>
      </aside>
    </div>
  );
}
