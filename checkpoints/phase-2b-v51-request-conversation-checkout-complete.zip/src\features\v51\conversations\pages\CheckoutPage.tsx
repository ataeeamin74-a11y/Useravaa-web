"use client";

import { useState } from "react";
import { V51Button, V51LinkButton } from "@/features/v51/components/V51Button";
import {
  calculateCheckout,
  getConversationStatusLabel,
  payConversation,
  type ConversationFixture
} from "@/features/v51/data/conversations";
import { CheckoutSummary } from "../components/CheckoutSummary";
import styles from "../components/ConversationCluster.module.css";

type CheckoutPageProps = {
  initialConversation: ConversationFixture;
};

export function CheckoutPage({ initialConversation }: CheckoutPageProps) {
  const [conversation, setConversation] = useState(initialConversation);
  const checkout = calculateCheckout(conversation);

  const submitPayment = () => {
    setConversation((current) => payConversation(current));
  };

  return (
    <div className={styles.shell}>
      <section className={styles.hero}>
        <div className={styles.heroText}>
          <h1>مرور و نهایی‌کردن گفت‌وگو</h1>
          <p className={styles.lead}>قبل از پرداخت، فرد، زمان و هزینه گفت‌وگو را یک‌بار بررسی کن.</p>
        </div>
        <V51LinkButton href={`/conversations/${conversation.id}`}>بازگشت</V51LinkButton>
      </section>

      <div className={styles.checkoutGrid}>
        <CheckoutSummary conversation={conversation} />
        <aside className={styles.panel}>
          <h2>کیف پول</h2>
          <p className={styles.infoBox}>اگر پرداخت کامل نشود، گفت‌وگو ثبت نمی‌شود و مبلغی از کیف پولت کم نخواهد شد.</p>
          <div className={styles.summaryRows}>
            <div className={styles.summaryRow}>
              <span>وضعیت</span>
              <strong>{getConversationStatusLabel(conversation)}</strong>
            </div>
            <div className={styles.summaryRow}>
              <span>پرداخت درگاه</span>
              <strong>{checkout.requiresGateway ? "نیاز دارد" : "نیاز ندارد"}</strong>
            </div>
          </div>
          <div className={styles.actions}>
            <V51Button type="button" tone="primary" onClick={submitPayment}>
              {checkout.isFreeHelp ? "نهایی‌کردن گفت‌وگو" : "پرداخت و نهایی‌کردن گفت‌وگو"}
            </V51Button>
          </div>
          {conversation.state === "scheduled" ? <p className={styles.successBox}>گفت‌وگو نهایی شد و وضعیت آن «برنامه‌ریزی‌شده» است.</p> : null}
        </aside>
      </div>
    </div>
  );
}
