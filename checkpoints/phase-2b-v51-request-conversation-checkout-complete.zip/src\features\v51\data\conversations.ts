import { formatter, getProfileById, profiles, toman, type ExperienceProfileFixture } from "./profiles";

export type ConversationDirection = "outgoing" | "incoming";

export type ConversationState =
  | "draft"
  | "requested"
  | "provider_time_options_sent"
  | "time_selected"
  | "awaiting_payment"
  | "scheduled"
  | "completed"
  | "feedback_pending"
  | "feedback_submitted"
  | "cancelled"
  | "expired";

export type ConversationDuration = 30 | 60;

export type ProposedTime = {
  id: string;
  dateId: string;
  dateLabel: string;
  dayLabel: string;
  timeLabel: string;
};

export type ConversationFixture = {
  id: string;
  direction: ConversationDirection;
  state: ConversationState;
  profile: ExperienceProfileFixture;
  requesterName: string;
  requesterRole: string;
  duration: ConversationDuration;
  note: string;
  submittedAtLabel: string;
  proposedAtLabel?: string;
  selectedTime?: ProposedTime;
  proposedTimes: ProposedTime[];
  walletBalanceToman?: number;
  freeHelp?: boolean;
  feedbackAllowed?: boolean;
};

export type ConversationBucket = "needsAction" | "tracking" | "done";

export type ConversationActionKind = "open" | "propose_times" | "select_time" | "checkout" | "cancel" | "feedback";

export type ConversationAction = {
  kind: ConversationActionKind;
  label: string;
  href?: string;
  tone: "primary" | "secondary" | "danger";
};

export const walletBalanceToman = 100000;

export const proposalDateOptions = [
  { id: "d1", day: "شنبه", date: "۲۶ خرداد ۱۴۰۵", full: "شنبه ۲۶ خرداد ۱۴۰۵" },
  { id: "d2", day: "یکشنبه", date: "۲۷ خرداد ۱۴۰۵", full: "یکشنبه ۲۷ خرداد ۱۴۰۵" },
  { id: "d3", day: "دوشنبه", date: "۲۸ خرداد ۱۴۰۵", full: "دوشنبه ۲۸ خرداد ۱۴۰۵" },
  { id: "d4", day: "سه‌شنبه", date: "۲۹ خرداد ۱۴۰۵", full: "سه‌شنبه ۲۹ خرداد ۱۴۰۵" },
  { id: "d5", day: "چهارشنبه", date: "۳۰ خرداد ۱۴۰۵", full: "چهارشنبه ۳۰ خرداد ۱۴۰۵" },
  { id: "d6", day: "پنجشنبه", date: "۳۱ خرداد ۱۴۰۵", full: "پنجشنبه ۳۱ خرداد ۱۴۰۵" },
  { id: "d7", day: "جمعه", date: "۱ تیر ۱۴۰۵", full: "جمعه ۱ تیر ۱۴۰۵" },
  { id: "d8", day: "شنبه", date: "۲ تیر ۱۴۰۵", full: "شنبه ۲ تیر ۱۴۰۵" },
  { id: "d9", day: "یکشنبه", date: "۳ تیر ۱۴۰۵", full: "یکشنبه ۳ تیر ۱۴۰۵" }
] as const;

export const proposalTimeSlots = [
  "۰۹:۰۰",
  "۰۹:۳۰",
  "۱۰:۰۰",
  "۱۰:۳۰",
  "۱۱:۰۰",
  "۱۱:۳۰",
  "۱۴:۰۰",
  "۱۴:۳۰",
  "۱۵:۰۰",
  "۱۵:۳۰",
  "۱۶:۰۰",
  "۱۶:۳۰",
  "۱۷:۰۰",
  "۱۷:۳۰",
  "۱۸:۰۰",
  "۱۸:۳۰",
  "۱۹:۰۰"
] as const;

const selectedTimeA = makeProposedTime("d2", "۱۰:۳۰");
const selectedTimeB = makeProposedTime("d5", "۱۶:۰۰");

const defaultProposedTimes = [
  makeProposedTime("d2", "۱۰:۳۰"),
  makeProposedTime("d3", "۱۵:۰۰"),
  makeProposedTime("d5", "۱۶:۰۰")
];

export const conversations = [
  {
    id: "conv-time-options",
    direction: "outgoing",
    state: "provider_time_options_sent",
    profile: profileOrThrow("sara"),
    requesterName: "تو",
    requesterRole: "درخواست‌دهنده",
    duration: 30,
    note: "می‌خواهم درباره آماده‌کردن پورتفولیو و مسیر ورود به Product Design حرف بزنم.",
    submittedAtLabel: "ثبت‌شده در ۲۴ خرداد ۱۴۰۵",
    proposedAtLabel: "۳ زمان پیشنهادی دریافت شده",
    proposedTimes: defaultProposedTimes,
    walletBalanceToman
  },
  {
    id: "conv-awaiting-payment",
    direction: "outgoing",
    state: "awaiting_payment",
    profile: profileOrThrow("ali"),
    requesterName: "تو",
    requesterRole: "درخواست‌دهنده",
    duration: 30,
    note: "می‌خواهم درباره ورود به Product و آماده‌کردن رزومه‌ام حرف بزنم.",
    submittedAtLabel: "ثبت‌شده در ۲۳ خرداد ۱۴۰۵",
    proposedAtLabel: "زمان انتخاب شده است",
    selectedTime: selectedTimeA,
    proposedTimes: defaultProposedTimes,
    walletBalanceToman
  },
  {
    id: "conv-provider-request",
    direction: "incoming",
    state: "requested",
    profile: profileOrThrow("reza"),
    requesterName: "مهسا ک.",
    requesterRole: "درخواست‌دهنده گفت‌وگو",
    duration: 60,
    note: "می‌خواهم درباره رشد مسیر مهندسی و تصمیم‌های مدیریتی حرف بزنم.",
    submittedAtLabel: "ثبت‌شده در ۲۵ خرداد ۱۴۰۵",
    proposedTimes: [],
    walletBalanceToman
  },
  {
    id: "conv-provider-waiting",
    direction: "incoming",
    state: "provider_time_options_sent",
    profile: profileOrThrow("nazanin"),
    requesterName: "آرش ن.",
    requesterRole: "درخواست‌دهنده گفت‌وگو",
    duration: 30,
    note: "برای ساخت داشبوردهای تصمیم‌سازی به راهنمایی نیاز دارم.",
    submittedAtLabel: "ثبت‌شده در ۲۲ خرداد ۱۴۰۵",
    proposedAtLabel: "زمان‌ها را پیشنهاد داده‌ای",
    proposedTimes: defaultProposedTimes,
    walletBalanceToman
  },
  {
    id: "conv-scheduled",
    direction: "outgoing",
    state: "scheduled",
    profile: profileOrThrow("mina"),
    requesterName: "تو",
    requesterRole: "درخواست‌دهنده",
    duration: 60,
    note: "درباره کمپین رشد و قیف جذب کاربر سوال دارم.",
    submittedAtLabel: "ثبت‌شده در ۲۰ خرداد ۱۴۰۵",
    proposedAtLabel: "گفت‌وگو قطعی شده است",
    selectedTime: selectedTimeB,
    proposedTimes: defaultProposedTimes,
    walletBalanceToman
  },
  {
    id: "conv-feedback",
    direction: "outgoing",
    state: "feedback_pending",
    profile: profileOrThrow("hamid"),
    requesterName: "تو",
    requesterRole: "درخواست‌دهنده",
    duration: 30,
    note: "برای شروع مسیر تحلیل داده راهنمایی می‌خواستم.",
    submittedAtLabel: "ثبت‌شده در ۱۸ خرداد ۱۴۰۵",
    proposedAtLabel: "گفت‌وگو تمام شده است",
    selectedTime: makeProposedTime("d1", "۱۱:۰۰"),
    proposedTimes: [makeProposedTime("d1", "۱۱:۰۰"), makeProposedTime("d2", "۱۶:۰۰"), makeProposedTime("d4", "۱۸:۰۰")],
    walletBalanceToman,
    feedbackAllowed: true
  },
  {
    id: "conv-free-help",
    direction: "outgoing",
    state: "awaiting_payment",
    profile: profileOrThrow("niloofar"),
    requesterName: "تو",
    requesterRole: "درخواست‌دهنده",
    duration: 30,
    note: "یک گفت‌وگوی کمکی کوتاه برای مسیر شغلی.",
    submittedAtLabel: "ثبت‌شده در ۲۱ خرداد ۱۴۰۵",
    proposedAtLabel: "زمان انتخاب شده است",
    selectedTime: makeProposedTime("d4", "۱۴:۳۰"),
    proposedTimes: [makeProposedTime("d2", "۱۰:۰۰"), makeProposedTime("d4", "۱۴:۳۰"), makeProposedTime("d6", "۱۷:۰۰")],
    walletBalanceToman,
    freeHelp: true
  }
] as const satisfies readonly ConversationFixture[];

export function makeProposedTime(dateId: string, timeLabel: string): ProposedTime {
  const dateOption = proposalDateOptions.find((item) => item.id === dateId) ?? proposalDateOptions[0];

  return {
    id: `${dateOption.id}-${timeLabel}`,
    dateId: dateOption.id,
    dateLabel: dateOption.full,
    dayLabel: dateOption.day,
    timeLabel
  };
}

export function profileOrThrow(profileId: string) {
  const profile = getProfileById(profileId);

  if (!profile) {
    throw new Error(`Missing V51 profile fixture: ${profileId}`);
  }

  return profile;
}

export function getConversationById(conversationId: string) {
  return conversations.find((conversation) => conversation.id === conversationId);
}

export function getConversationOrFallback(conversationId: string, fallbackId = "conv-time-options") {
  return getConversationById(conversationId) ?? getMockRequestConversation(conversationId) ?? getConversationById(fallbackId) ?? conversations[0];
}

export function getPersonName(conversation: ConversationFixture) {
  return conversation.direction === "incoming" ? conversation.requesterName : conversation.profile.name;
}

export function getPersonRole(conversation: ConversationFixture) {
  return conversation.direction === "incoming" ? conversation.requesterRole : conversation.profile.roleFa;
}

export function formatDuration(duration: ConversationDuration) {
  return duration === 30 ? "۳۰ دقیقه" : "۱ ساعت";
}

export function getConversationPrice(conversation: Pick<ConversationFixture, "duration" | "freeHelp" | "profile">) {
  if (conversation.freeHelp) {
    return 0;
  }

  return conversation.profile.pricing[conversation.duration] ?? 0;
}

export function formatPrice(conversation: Pick<ConversationFixture, "duration" | "freeHelp" | "profile">) {
  const price = getConversationPrice(conversation);
  return price === 0 ? "رایگان" : toman(price);
}

export function formatToman(value: number) {
  return `${formatter.format(value)} تومان`;
}

export function getConversationStatusLabel(conversation: ConversationFixture) {
  if (conversation.state === "requested" && conversation.direction === "incoming") {
    return "درخواست جدید";
  }

  if (conversation.state === "requested") {
    return "منتظر زمان";
  }

  if (conversation.state === "provider_time_options_sent" && conversation.direction === "outgoing") {
    return "انتخاب زمان";
  }

  if (conversation.state === "provider_time_options_sent") {
    return "منتظر انتخاب";
  }

  const labels: Record<ConversationState, string> = {
    draft: "پیش‌نویس",
    requested: "درخواست جدید",
    provider_time_options_sent: "زمان‌ها ارسال شدند",
    time_selected: "زمان انتخاب شد",
    awaiting_payment: "نهایی‌سازی",
    scheduled: "برنامه‌ریزی‌شده",
    completed: "تمام‌شده",
    feedback_pending: "تمام‌شده",
    feedback_submitted: "انجام‌شده",
    cancelled: "لغو شده",
    expired: "منقضی شده"
  };

  return labels[conversation.state];
}

export function getConversationMessage(conversation: ConversationFixture) {
  const name = getPersonName(conversation);

  if (conversation.state === "requested" && conversation.direction === "incoming") {
    return `${name} از تو درخواست گفت‌وگو کرده.`;
  }

  if (conversation.state === "requested") {
    return `درخواستت برای ${name} ارسال شده.`;
  }

  if (conversation.state === "provider_time_options_sent" && conversation.direction === "outgoing") {
    return `${name} چند زمان پیشنهادی فرستاده.`;
  }

  if (conversation.state === "provider_time_options_sent") {
    return `برای ${name} زمان پیشنهاد داده‌ای.`;
  }

  if (conversation.state === "awaiting_payment") {
    return `زمان گفت‌وگو با ${name} انتخاب شده.`;
  }

  if (conversation.state === "scheduled") {
    return `گفت‌وگو با ${name} قطعی شده.`;
  }

  if (conversation.state === "feedback_pending") {
    return `گفت‌وگو با ${name} تمام شده.`;
  }

  if (conversation.state === "feedback_submitted" || conversation.state === "completed") {
    return `گفت‌وگو با ${name} کامل شده.`;
  }

  if (conversation.state === "cancelled") {
    return `درخواست مربوط به ${name} لغو شده.`;
  }

  if (conversation.state === "expired") {
    return `درخواست مربوط به ${name} منقضی شده.`;
  }

  return "جزئیات گفت‌وگو آماده است.";
}

export function getNextActionText(conversation: ConversationFixture) {
  if (conversation.state === "requested" && conversation.direction === "incoming") {
    return "این فرد برای گفت‌وگو با تو درخواست داده است. حداقل سه زمان پیشنهاد بده یا درخواست را لغو کن.";
  }

  if (conversation.state === "requested") {
    return "منتظر زمان‌های پیشنهادی هستی. بعد از دریافت زمان‌ها، یکی را انتخاب می‌کنی.";
  }

  if (conversation.state === "provider_time_options_sent" && conversation.direction === "outgoing") {
    return "سه زمان پیشنهادی دریافت شده است. یکی را انتخاب کن یا درخواست را لغو کن.";
  }

  if (conversation.state === "provider_time_options_sent") {
    return "زمان‌ها را پیشنهاد داده‌ای. حالا منتظر انتخاب درخواست‌دهنده هستی.";
  }

  if (conversation.state === "awaiting_payment") {
    return "زمان انتخاب شده است. برای نهایی‌شدن گفت‌وگو، پرداخت را کامل کن.";
  }

  if (conversation.state === "scheduled") {
    return "گفت‌وگو نهایی شده و در برنامه تو قرار گرفته است.";
  }

  if (conversation.state === "feedback_pending") {
    return "این گفت‌وگو تمام شده است. اگر خواستی، می‌توانی بازخورد ثبت کنی.";
  }

  if (conversation.state === "feedback_submitted" || conversation.state === "completed") {
    return "این گفت‌وگو کامل شده و بازخورد ثبت شده است.";
  }

  if (conversation.state === "cancelled") {
    return "این درخواست لغو شده است.";
  }

  if (conversation.state === "expired") {
    return "این درخواست منقضی شده است.";
  }

  return "وضعیت گفت‌وگو را پیگیری کن.";
}

export function bucketConversation(conversation: ConversationFixture): ConversationBucket {
  if (conversation.direction === "outgoing") {
    if (conversation.state === "provider_time_options_sent" || conversation.state === "awaiting_payment" || conversation.state === "feedback_pending") {
      return "needsAction";
    }

    if (conversation.state === "requested" || conversation.state === "scheduled") {
      return "tracking";
    }

    return "done";
  }

  if (conversation.state === "requested") {
    return "needsAction";
  }

  if (conversation.state === "provider_time_options_sent" || conversation.state === "scheduled") {
    return "tracking";
  }

  return "done";
}

export function groupConversations(items: readonly ConversationFixture[], direction: ConversationDirection) {
  const visibleItems = items.filter((conversation) => conversation.direction === direction);

  return {
    needsAction: visibleItems.filter((conversation) => bucketConversation(conversation) === "needsAction"),
    tracking: visibleItems.filter((conversation) => bucketConversation(conversation) === "tracking"),
    done: visibleItems.filter((conversation) => bucketConversation(conversation) === "done")
  };
}

export function getPrimaryConversationAction(conversation: ConversationFixture): ConversationAction {
  if (conversation.state === "requested" && conversation.direction === "incoming") {
    return {
      kind: "propose_times",
      label: "پیشنهاد زمان",
      href: `/conversations/${conversation.id}/propose-times`,
      tone: "primary"
    };
  }

  if (conversation.state === "provider_time_options_sent" && conversation.direction === "outgoing") {
    return {
      kind: "select_time",
      label: "انتخاب زمان",
      href: `/conversations/${conversation.id}/select-time`,
      tone: "primary"
    };
  }

  if (conversation.state === "awaiting_payment") {
    return {
      kind: "checkout",
      label: "پرداخت",
      href: `/checkout/${conversation.id}`,
      tone: "primary"
    };
  }

  if (conversation.state === "feedback_pending" && conversation.feedbackAllowed) {
    return {
      kind: "feedback",
      label: "ثبت بازخورد",
      href: `/conversations/${conversation.id}`,
      tone: "primary"
    };
  }

  return {
    kind: "open",
    label: "باز کردن",
    href: `/conversations/${conversation.id}`,
    tone: "secondary"
  };
}

export function canCancelConversation(conversation: ConversationFixture) {
  return (
    conversation.state === "requested" ||
    conversation.state === "provider_time_options_sent" ||
    conversation.state === "time_selected" ||
    conversation.state === "awaiting_payment"
  );
}

export function getConversationActions(conversation: ConversationFixture) {
  const actions = [getPrimaryConversationAction(conversation)];

  if (canCancelConversation(conversation)) {
    actions.push({
      kind: "cancel",
      label: "لغو درخواست",
      href: `/conversations/${conversation.id}`,
      tone: "danger"
    });
  }

  return actions;
}

export function createConversationRequest({
  profile,
  duration,
  note
}: {
  profile: ExperienceProfileFixture;
  duration: ConversationDuration;
  note: string;
}): ConversationFixture {
  return {
    id: `mock-request-${profile.id}-${duration}`,
    direction: "outgoing",
    state: "requested",
    profile,
    requesterName: "تو",
    requesterRole: "درخواست‌دهنده",
    duration,
    note,
    submittedAtLabel: "همین حالا ثبت شد",
    proposedTimes: [],
    walletBalanceToman
  };
}

export function getMockRequestConversation(conversationId: string) {
  const match = /^mock-request-(.+)-(30|60)$/.exec(conversationId);

  if (!match) {
    return undefined;
  }

  const profile = getProfileById(match[1]);

  if (!profile) {
    return undefined;
  }

  return createConversationRequest({
    profile,
    duration: Number(match[2]) as ConversationDuration,
    note: ""
  });
}

export function hasDuplicateProposedTime(selectedTimes: readonly ProposedTime[], nextTime: ProposedTime) {
  return selectedTimes.some((time) => time.id === nextTime.id);
}

export function toggleProposedTime(selectedTimes: readonly ProposedTime[], nextTime: ProposedTime) {
  if (hasDuplicateProposedTime(selectedTimes, nextTime)) {
    return selectedTimes.filter((time) => time.id !== nextTime.id);
  }

  if (selectedTimes.length >= 6) {
    return [...selectedTimes];
  }

  return [...selectedTimes, nextTime];
}

export function canSubmitProposedTimes(selectedTimes: readonly ProposedTime[]) {
  return selectedTimes.length >= 3 && selectedTimes.length <= 6;
}

export function proposeTimesForConversation(conversation: ConversationFixture, selectedTimes: readonly ProposedTime[]): ConversationFixture {
  if (!canSubmitProposedTimes(selectedTimes)) {
    return conversation;
  }

  return {
    ...conversation,
    state: "provider_time_options_sent",
    proposedAtLabel: `${formatter.format(selectedTimes.length)} زمان پیشنهادی ارسال شد`,
    proposedTimes: [...selectedTimes]
  };
}

export function selectTimeForConversation(conversation: ConversationFixture, proposedTimeId: string): ConversationFixture {
  const selectedTime = conversation.proposedTimes.find((time) => time.id === proposedTimeId);

  if (!selectedTime) {
    return conversation;
  }

  return {
    ...conversation,
    state: "awaiting_payment",
    selectedTime
  };
}

export function cancelConversation(conversation: ConversationFixture): ConversationFixture {
  if (!canCancelConversation(conversation)) {
    return conversation;
  }

  return {
    ...conversation,
    state: "cancelled"
  };
}

export function calculateCheckout(conversation: ConversationFixture, walletBalance = conversation.walletBalanceToman ?? walletBalanceToman) {
  const price = getConversationPrice(conversation);
  const walletDeduction = Math.min(price, walletBalance);
  const gatewayPayable = Math.max(price - walletDeduction, 0);

  return {
    price,
    walletBalance,
    walletDeduction,
    gatewayPayable,
    requiresGateway: gatewayPayable > 0,
    isFreeHelp: price === 0
  };
}

export function payConversation(conversation: ConversationFixture): ConversationFixture {
  const checkout = calculateCheckout(conversation);

  if (conversation.state !== "awaiting_payment" && !checkout.isFreeHelp) {
    return conversation;
  }

  return {
    ...conversation,
    state: "scheduled"
  };
}

export function getDefaultRequestProfile(profileId?: string | null) {
  return getProfileById(profileId ?? "") ?? profiles[0];
}
