import { networkCategoryFilters, type NetworkFilters, type NetworkSort } from "@/features/v51/data/my-profile";
import styles from "./MyProfile.module.css";

type NetworkToolbarProps = Readonly<{
  filters: NetworkFilters;
  onChange: (filters: NetworkFilters) => void;
}>;

export function NetworkToolbar({ filters, onChange }: NetworkToolbarProps) {
  return (
    <div className={styles.networkToolbar}>
      <input
        aria-label="جستجو در شبکه من"
        placeholder="جستجو در شبکه من"
        value={filters.query}
        onChange={(event) => onChange({ ...filters, query: event.target.value })}
      />
      <span className={styles.networkSelectWrap}>
        <select
          aria-label="فیلتر دسته‌بندی شبکه"
          value={filters.category}
          onChange={(event) => onChange({ ...filters, category: event.target.value })}
        >
          <option value="">همه دسته‌بندی‌ها</option>
          {networkCategoryFilters.map((category) => (
            <option key={category}>{category}</option>
          ))}
        </select>
        <span className={styles.networkCaret}>⌄</span>
      </span>
      <span className={styles.networkSelectWrap}>
        <select aria-label="مرتب‌سازی شبکه" value={filters.sort} onChange={(event) => onChange({ ...filters, sort: event.target.value as NetworkSort })}>
          <option value="recent">جدیدترین</option>
          <option value="level">رده سازمانی</option>
          <option value="name">نام</option>
        </select>
        <span className={styles.networkCaret}>⌄</span>
      </span>
    </div>
  );
}
