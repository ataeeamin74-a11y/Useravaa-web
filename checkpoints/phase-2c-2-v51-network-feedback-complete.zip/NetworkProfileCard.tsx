import { V51Button, V51LinkButton } from "@/features/v51/components/V51Button";
import { type NetworkProfile, type NetworkTab } from "@/features/v51/data/my-profile";
import styles from "./MyProfile.module.css";

type NetworkProfileCardProps = Readonly<{
  profile: NetworkProfile;
  activeTab: NetworkTab;
  onToggleFollow: (profileId: string) => void;
  onRemoveSaved: (profileId: string) => void;
}>;

export function NetworkProfileCard({ profile, activeTab, onToggleFollow, onRemoveSaved }: NetworkProfileCardProps) {
  const isFollower = activeTab === "followers";
  const isSaved = activeTab === "saved";

  return (
    <article className={styles.networkCard}>
      <div className={styles.networkPerson}>
        <div className={styles.networkAvatar}>{profile.initials || "؟"}</div>
        <div>
          <b>{profile.name}</b>
          <span>
            {profile.roleFa}
            {profile.orgLevel ? ` · ${profile.orgLevel}` : ""}
          </span>
        </div>
      </div>
      <p>{profile.followerSince ?? profile.reason}</p>
      <div className={styles.networkActions}>
        <V51LinkButton href={`/profiles/${profile.id}`} tone="primary">
          دیدن تجربه
        </V51LinkButton>
        {!isFollower ? (
          <V51Button type="button" onClick={() => onToggleFollow(profile.id)}>
            {profile.isFollowing ? "دنبال نکردن" : "دنبال کردن"}
          </V51Button>
        ) : null}
        {isSaved ? (
          <V51Button type="button" onClick={() => onRemoveSaved(profile.id)}>
            حذف از ذخیره‌شده‌ها
          </V51Button>
        ) : null}
      </div>
    </article>
  );
}
