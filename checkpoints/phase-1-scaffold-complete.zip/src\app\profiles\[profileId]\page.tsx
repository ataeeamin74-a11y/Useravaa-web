import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function ProfileDetailPage() {
  return <RoutePlaceholder routeId="profileDetail" />;
}
