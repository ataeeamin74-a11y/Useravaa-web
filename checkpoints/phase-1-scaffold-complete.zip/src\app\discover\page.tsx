import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function DiscoverPage() {
  return <RoutePlaceholder routeId="discover" />;
}
