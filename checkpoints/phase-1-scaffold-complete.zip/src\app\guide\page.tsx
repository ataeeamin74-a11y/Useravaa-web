import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function GuidePage() {
  return <RoutePlaceholder routeId="guide" />;
}
