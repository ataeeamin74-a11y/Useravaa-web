import fs from "node:fs";
import path from "node:path";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { DiscoverPage } from "@/features/v51/discover/DiscoverPage";
import {
  deriveQuestionFieldsFromTimeline,
  experienceAnswerStatuses,
  experienceQuestionTemplates,
  forbiddenExperienceAnswerStatuses,
  getActiveWeeklyQuestion,
  getPublishedProfileAnswers,
  publishExperienceAnswer,
  retractExperienceAnswer,
  templateIsEligible,
  weeklyQuestionCopy,
  type ExperienceAnswer
} from "@/features/v51/data/experience-questions";
import { initialExperienceTimeline, validateTimelineItem, type ExperienceTimelineItem } from "@/features/v51/data/experience-timeline";
import { invalidLegacyJobFieldValues, isValidJobField, jobFieldTaxonomy, validateJobField, validateJobTitle, type JobField } from "@/features/v51/data/job-fields";
import { initialBuilderDraft } from "@/features/v51/data/my-profile";
import { categoryOptions, profiles } from "@/features/v51/data/profiles";
import { NotificationsPage } from "@/features/v51/notifications/NotificationsPage";
import { ProfileDashboardPage } from "@/features/v51/my-profile/pages/ProfileDashboardPage";
import { ProfileBuilderPage } from "@/features/v51/my-profile/pages/ProfileBuilderPage";
import { JobFieldSelect } from "@/features/v51/my-profile/components/JobFieldSelect";
import { JobTitleInput } from "@/features/v51/my-profile/components/JobTitleInput";
import { WeeklyQuestionCard } from "@/features/v51/my-profile/components/WeeklyQuestionCard";
import { ProfileExperienceAnswersSection } from "@/features/v51/profile/ProfileExperienceAnswersSection";
import { ProfileDetailPage } from "@/features/v51/profile/ProfileDetailPage";
import { profileFromBuilderDraft, submitProfileForReview, validateProfileDraft } from "@/features/v51/data/my-profile";

function readProjectFile(relativePath: string) {
  return fs.readFileSync(path.join(process.cwd(), relativePath), "utf8");
}

describe("Profile timeline, job field taxonomy, and EQE integration", () => {
  it("/profile renders WeeklyQuestionCard for Provider when active question exists", () => {
    const html = renderToStaticMarkup(<ProfileDashboardPage />);

    expect(html).toContain("id=\"weekly-question\"");
    expect(html).toContain(weeklyQuestionCopy.title);
    expect(html).toContain(weeklyQuestionCopy.answerAction);
  });

  it("WeeklyQuestionCard is placed after profile status/hero and before dashboard sections", () => {
    const html = renderToStaticMarkup(<ProfileDashboardPage />);

    expect(html.indexOf("پروفایل تجربه تو فعال است")).toBeLessThan(html.indexOf("id=\"weekly-question\""));
    expect(html.indexOf("id=\"weekly-question\"")).toBeLessThan(html.indexOf("پروفایل تجربه من"));
  });

  it("raw unanswered question does not render on /profiles/[profileId]", () => {
    const activeQuestion = getActiveWeeklyQuestion(initialExperienceTimeline, initialBuilderDraft.categories);
    const html = renderToStaticMarkup(<ProfileDetailPage profile={profiles[0]} />);

    expect(activeQuestion).not.toBeNull();
    expect(html).not.toContain(activeQuestion!.renderedQuestion);
  });

  it("published answers render inside “از تجربه من” on /profiles/[profileId]", () => {
    const html = renderToStaticMarkup(<ProfileDetailPage profile={profiles[0]} />);

    expect(html).toContain("از تجربه من");
    expect(html).toContain("توانایی تبدیل ابهام");
  });

  it("“از تجربه من” is hidden when there are no published answers", () => {
    const html = renderToStaticMarkup(<ProfileExperienceAnswersSection profileId="sara" answers={[]} />);

    expect(html).not.toContain("از تجربه من");
  });

  it("max 3 published answers render", () => {
    const html = renderToStaticMarkup(<ProfileExperienceAnswersSection profileId="ali" />);

    expect(html.match(/experienceAnswerItem/g) ?? []).toHaveLength(3);
    expect(getPublishedProfileAnswers("ali")).toHaveLength(3);
  });

  it("notification links to /profile#weekly-question and does not include full question text", () => {
    const activeQuestion = getActiveWeeklyQuestion(initialExperienceTimeline, initialBuilderDraft.categories);
    const html = renderToStaticMarkup(<NotificationsPage />);

    expect(html).toContain("/profile#weekly-question");
    expect(html).toContain(weeklyQuestionCopy.notificationTitle);
    expect(html).not.toContain(activeQuestion!.renderedQuestion);
  });

  it("weekly question rendering updates when the current timeline jobTitle changes", () => {
    const originalQuestion = getActiveWeeklyQuestion(initialExperienceTimeline, initialBuilderDraft.categories);
    const changedTimeline = initialExperienceTimeline.map((item) => (item.isCurrent ? { ...item, jobTitle: "تحلیلگر داده" } : item));
    const question = getActiveWeeklyQuestion(changedTimeline, initialBuilderDraft.categories);

    expect(originalQuestion?.renderedQuestion).toContain("در نقش مدیر محصول");
    expect(question?.renderedQuestion).not.toContain("در نقش مدیر محصول");
    expect(question?.renderedQuestion).toContain("در نقش تحلیلگر داده");
  });

  it("current timeline jobTitle overrides stale profile role state", () => {
    const changedTimeline = initialExperienceTimeline.map((item) => (item.isCurrent ? { ...item, jobTitle: "تحلیلگر داده" } : item));
    const profile = profileFromBuilderDraft({ ...initialBuilderDraft, role: "مدیر محصول", timeline: changedTimeline });

    expect(profile.roleFa).toBe("تحلیلگر داده");
  });

  it("missing current timeline item renders a validation state instead of a fake role question", () => {
    const withoutCurrent = initialExperienceTimeline.map((item) => ({ ...item, isCurrent: false }));
    const question = getActiveWeeklyQuestion(withoutCurrent, initialBuilderDraft.categories);
    const html = renderToStaticMarkup(<WeeklyQuestionCard question={question} />);

    expect(question).toBeNull();
    expect(html).toContain("عنوان شغلی فعلی");
    expect(html).not.toContain("مدیر محصول");
  });

  it("profile builder UI uses عنوان شغلی and does not render نقش اصلی", () => {
    const html = renderToStaticMarkup(<ProfileBuilderPage />);

    expect(html).toContain("عنوان شغلی");
    expect(html).not.toContain("نقش اصلی");
  });

  it("publish is blocked without responsibility checkbox", () => {
    const draft: ExperienceAnswer = {
      id: "draft",
      profileId: "ali",
      questionId: "q1",
      renderedQuestion: "پرسش",
      answer: "پاسخ کوتاه حرفه‌ای",
      status: "draft",
      publishedAt: null
    };

    const result = publishExperienceAnswer(draft, false);

    expect(result.published).toBe(false);
    expect(result.answer.status).toBe("draft");
  });

  it("publishing valid answer changes status from draft to published", () => {
    const draft: ExperienceAnswer = {
      id: "draft",
      profileId: "ali",
      questionId: "q1",
      renderedQuestion: "پرسش",
      answer: "پاسخ کوتاه حرفه‌ای",
      status: "draft",
      publishedAt: null
    };

    const result = publishExperienceAnswer(draft, true);

    expect(result.published).toBe(true);
    expect(result.answer.status).toBe("published");
  });

  it("Provider can retract own published answer", () => {
    const published = getPublishedProfileAnswers("ali")[0];
    const retracted = retractExperienceAnswer(published);

    expect(retracted.status).toBe("retracted");
  });

  it("retracted answer disappears from public profile", () => {
    const published = getPublishedProfileAnswers("ali")[0];
    const retracted = retractExperienceAnswer(published);

    expect(getPublishedProfileAnswers("ali", [retracted])).toHaveLength(0);
  });

  it("no Admin routes, states, or components are added for EQE", () => {
    expect(experienceAnswerStatuses).toEqual(["draft", "published", "retracted"]);
    expect(forbiddenExperienceAnswerStatuses.every((status) => !(experienceAnswerStatuses as readonly string[]).includes(status))).toBe(true);
    expect(fs.existsSync(path.join(process.cwd(), "src/app/admin/experience-answers"))).toBe(false);
    expect(fs.existsSync(path.join(process.cwd(), "src/features/v51/admin"))).toBe(false);
  });

  it("timeline item requires job title, job field, org level, company name, company country, start date, and end date unless current", () => {
    const invalid = {
      ...initialExperienceTimeline[0],
      jobTitle: "",
      jobField: "محصول",
      orgLevel: "",
      companyName: "",
      companyCountry: "",
      companyIndustry: "",
      startYear: 0,
      startMonth: 0,
      isCurrent: false,
      endYear: null,
      endMonth: null
    } as unknown as ExperienceTimelineItem;

    const errors = validateTimelineItem(invalid);

    expect(errors.jobTitle).toBe("عنوان شغلی را کامل وارد کنید.");
    expect(errors.jobField).toBe("حوزه شغلی را از لیست انتخاب کنید.");
    expect(errors.orgLevel).toBe("رده سازمانی را انتخاب کن.");
    expect(errors.companyName).toBe("نام شرکت را کامل وارد کن.");
    expect(errors.companyCountry).toBe("کشور یا محل شرکت را وارد کن.");
    expect(errors.companyIndustry).toBe("زمینه فعالیت شرکت را وارد کن.");
    expect(errors.startDate).toBe("تاریخ شروع را کامل وارد کن.");
    expect(errors.endDate).toBe("برای سابقه قبلی، تاریخ پایان را وارد کن.");
  });

  it("jobTitle accepts manual free text and is rendered as an input", () => {
    const html = renderToStaticMarkup(<JobTitleInput value="مدیرعامل رشد محصول" onChange={() => undefined} />);

    expect(validateJobTitle("مدیرعامل رشد محصول")).toBe("");
    expect(html).toContain("مدیرعامل رشد محصول");
    expect(html).toContain("<input");
  });

  it("jobField only accepts the fixed taxonomy and is rendered as a select", () => {
    const html = renderToStaticMarkup(<JobFieldSelect value="محصول و تجربه کاربر" onChange={() => undefined} />);

    expect(isValidJobField("محصول و تجربه کاربر")).toBe(true);
    expect(validateJobField("محصول")).toBe("حوزه شغلی را از لیست انتخاب کنید.");
    expect(html).toContain("<select");
    expect(html).toContain("محصول و تجربه کاربر");
  });

  it("profile form accepts exactly one selected jobField", () => {
    const validDraft = { ...initialBuilderDraft, categories: ["محصول و تجربه کاربر" as JobField] };
    const invalidDraft = { ...initialBuilderDraft, categories: ["محصول و تجربه کاربر", "علوم داده و هوش مصنوعی"] as JobField[] };

    expect(validateProfileDraft(validDraft).categories).toBeUndefined();
    expect(validateProfileDraft(invalidDraft).categories).toBe("حوزه شغلی را از لیست انتخاب کن.");
  });

  it("jobField dropdown options are exactly the fixed taxonomy list", () => {
    const html = renderToStaticMarkup(<JobFieldSelect value="محصول و تجربه کاربر" onChange={() => undefined} />);

    expect(html.match(/<option/g) ?? []).toHaveLength(jobFieldTaxonomy.length);
    jobFieldTaxonomy.forEach((field) => {
      expect(html).toContain(`value="${field}"`);
    });
  });

  it("invalid old values are not accepted as standalone jobField values unless mapped to fixed taxonomy", () => {
    invalidLegacyJobFieldValues.forEach((value) => {
      expect(isValidJobField(value)).toBe(false);
    });
  });

  it("current role/seniority/company are derived from timeline item with isCurrent=true", () => {
    const fields = deriveQuestionFieldsFromTimeline(initialExperienceTimeline, initialBuilderDraft.categories);

    expect(fields.current_role).toBe("مدیر محصول");
    expect(fields.current_seniority).toBe("مدیر میانی");
    expect(fields.current_company).toBe("اسنپ");
    expect(fields.current_company_country).toBe("ایران");
  });

  it("previous role/seniority/company are derived from most recent non-current timeline item", () => {
    const fields = deriveQuestionFieldsFromTimeline(initialExperienceTimeline, initialBuilderDraft.categories);

    expect(fields.previous_role).toBe("تحلیلگر داده محصول");
    expect(fields.previous_seniority).toBe("کارشناس ارشد");
    expect(fields.previous_company).toBe("دیجی‌کالا");
  });

  it("{current_role} uses jobTitle and {job_category} uses jobField", () => {
    const fields = deriveQuestionFieldsFromTimeline(initialExperienceTimeline, []);

    expect(fields.current_role).toBe(initialExperienceTimeline[0].jobTitle);
    expect(fields.job_category).toBe(initialExperienceTimeline[0].jobField);
  });

  it("company comparison templates are eligible only when current and previous company can be derived from timeline", () => {
    const companyTemplate = experienceQuestionTemplates.find((template) => template.category === "company_environment");
    expect(companyTemplate).toBeDefined();

    const currentOnly = deriveQuestionFieldsFromTimeline([initialExperienceTimeline[0]], initialBuilderDraft.categories);
    const full = deriveQuestionFieldsFromTimeline(initialExperienceTimeline, initialBuilderDraft.categories);

    expect(templateIsEligible(companyTemplate!, currentOnly)).toBe(false);
    expect(templateIsEligible(companyTemplate!, full)).toBe(true);
  });

  it("seniority comparison templates are eligible only when current and previous seniority can be derived from timeline", () => {
    const seniorityTemplate = experienceQuestionTemplates.find((template) => template.category === "seniority_difference");
    expect(seniorityTemplate).toBeDefined();

    const currentOnly = deriveQuestionFieldsFromTimeline([initialExperienceTimeline[0]], initialBuilderDraft.categories);
    const full = deriveQuestionFieldsFromTimeline(initialExperienceTimeline, initialBuilderDraft.categories);

    expect(templateIsEligible(seniorityTemplate!, currentOnly)).toBe(false);
    expect(templateIsEligible(seniorityTemplate!, full)).toBe(true);
  });

  it("free-text previousCompanies is not used as source of truth for Question Engine eligibility", () => {
    const freeTextPreviousCompanies = ["دیجی‌کالا"];
    const fields = deriveQuestionFieldsFromTimeline([initialExperienceTimeline[0]], initialBuilderDraft.categories);

    expect(freeTextPreviousCompanies).toContain("دیجی‌کالا");
    expect(fields.previous_company).toBeUndefined();
  });

  it("profile builder form does not render the previous-companies tag input", () => {
    const html = renderToStaticMarkup(<ProfileBuilderPage />);

    expect(html).not.toContain("شرکت‌های قبلی");
    expect(html).not.toContain("نام شرکت را بنویس و Enter بزن");
  });

  it("public/profile summary does not require duplicate previous company entry", () => {
    const draftWithoutPreviousCompanyTags = { ...initialBuilderDraft, companies: [] };
    const result = submitProfileForReview(draftWithoutPreviousCompanyTags);
    const profile = profileFromBuilderDraft(draftWithoutPreviousCompanyTags);

    expect(result.status).toBe("pending_review");
    expect(profile.previousCompaniesFa).toEqual(["دیجی‌کالا"]);
  });

  it("discovery job-field filters show exactly the fixed taxonomy list", () => {
    const html = renderToStaticMarkup(<DiscoverPage initialState="ready" />);
    const source = readProjectFile("src/features/v51/data/profiles.ts");

    expect(categoryOptions).toEqual(jobFieldTaxonomy);
    expect(source).toContain("categoryOptions = [...jobFieldTaxonomy]");
    jobFieldTaxonomy.forEach((field) => {
      expect(html).toContain(field);
    });
  });
});
