import { getCurrentTimelineItem, getPreviousTimelineItem, type ExperienceTimelineItem } from "./experience-timeline";
import { isValidJobField, type JobField } from "./job-fields";

export type ExperienceAnswerStatus = "draft" | "published" | "retracted";
export type ExperienceQuestionStatus = "active" | "replaced" | "skipped" | "expired";
export type ExperienceQuestionCategory = "hidden_role_reality" | "seniority_difference" | "company_environment" | "job_category_nature";

export type ExperienceQuestionTemplate = {
  id: string;
  category: ExperienceQuestionCategory;
  templateText: string;
  requiredFields: Array<keyof QuestionFieldMapping>;
};

export type QuestionFieldMapping = {
  current_role?: string;
  current_seniority?: string;
  current_company?: string;
  current_company_country?: string;
  previous_role?: string;
  previous_seniority?: string;
  previous_company?: string;
  job_category?: JobField;
};

export type ExperienceQuestion = {
  id: string;
  templateId: string;
  status: ExperienceQuestionStatus;
  renderedQuestion: string;
};

export type ExperienceAnswer = {
  id: string;
  profileId: string;
  questionId: string;
  renderedQuestion: string;
  answer: string;
  status: ExperienceAnswerStatus;
  publishedAt: string | null;
};

export const experienceAnswerStatuses = ["draft", "published", "retracted"] as const;
export const forbiddenExperienceAnswerStatuses = ["pending_review", "rejected", "hidden"] as const;

export const weeklyQuestionCopy = {
  title: "پرسش این هفته",
  description: "پاسخ کوتاه شما به کامل‌تر شدن پروفایل تجربه‌تان کمک می‌کند.",
  answerAction: "پاسخ می‌دهم",
  replaceAction: "سؤال دیگری بده",
  skipAction: "فعلاً نه",
  answerHelper: "۳ تا ۵ جمله کافی است. پاسخ را بر اساس تجربه شخصی خودتان، حرفه‌ای و بدون افشای اطلاعات محرمانه بنویسید.",
  safetyText:
    "پاسخ را حرفه‌ای، محترمانه و بدون افشای اطلاعات محرمانه بنویسید. هدف، توضیح تجربه شخصی شماست، نه ارزیابی یا تخریب شرکت‌ها.",
  responsibilityText: "مسئولیت محتوای این پاسخ با من است.",
  publishAction: "انتشار در پروفایل",
  retractAction: "حذف از پروفایل",
  publicSectionTitle: "از تجربه من",
  notificationTitle: "پرسش این هفته آماده است",
  notificationTarget: "/profile#weekly-question"
};

export const experienceQuestionTemplates: ExperienceQuestionTemplate[] = [
  {
    id: "EQE-T-001",
    category: "hidden_role_reality",
    templateText: "در نقش {current_role}، کدام بخش کار از بیرون ساده به نظر می‌رسد اما در عمل بیشترین انرژی را می‌گیرد؟",
    requiredFields: ["current_role"]
  },
  {
    id: "EQE-T-015",
    category: "seniority_difference",
    templateText: "در حرکت از {previous_seniority} به {current_seniority}، بیشترین تغییر در نوع پاسخ‌گویی تو چه بود؟",
    requiredFields: ["previous_seniority", "current_seniority"]
  },
  {
    id: "EQE-T-021",
    category: "company_environment",
    templateText: "کار در {previous_company} و {current_company} از نظر سرعت تصمیم‌گیری چه تفاوت عملی داشت؟",
    requiredFields: ["previous_company", "current_company"]
  },
  {
    id: "EQE-T-031",
    category: "job_category_nature",
    templateText: "در {job_category}، کدام مهارت کمتر درباره‌اش حرف زده می‌شود اما در عمل تعیین‌کننده است؟",
    requiredFields: ["job_category"]
  }
];

export const initialExperienceAnswers: ExperienceAnswer[] = [
  {
    id: "answer-published-4",
    profileId: "ali",
    questionId: "published-q-4",
    renderedQuestion: "در محصول و تجربه کاربر، کدام مهارت کمتر درباره‌اش حرف زده می‌شود اما در عمل تعیین‌کننده است؟",
    answer:
      "توانایی تبدیل ابهام به چند تصمیم کوچک خیلی تعیین‌کننده است. در کار روزمره محصول، همیشه اطلاعات کامل نیست و باید با تیم‌ها به یک مسیر قابل اجرا رسید. این مهارت از بیرون ساده دیده می‌شود، اما کیفیت تصمیم‌ها را تغییر می‌دهد.",
    status: "published",
    publishedAt: "2026-05-20T09:00:00.000Z"
  },
  {
    id: "answer-published-3",
    profileId: "ali",
    questionId: "published-q-3",
    renderedQuestion: "کار در دیجی‌کالا و اسنپ از نظر سرعت تصمیم‌گیری چه تفاوت عملی داشت؟",
    answer:
      "در اسنپ سرعت چرخه تصمیم‌گیری بیشتر به هماهنگی بین عملیات و محصول وابسته بود. در دیجی‌کالا، داده و آزمایش نقش پررنگ‌تری در متقاعد کردن ذی‌نفعان داشت. هر دو فضا یاد دادند که تصمیم خوب فقط خروجی تحلیل نیست و به زمینه سازمانی هم وابسته است.",
    status: "published",
    publishedAt: "2026-05-18T09:00:00.000Z"
  },
  {
    id: "answer-published-2",
    profileId: "ali",
    questionId: "published-q-2",
    renderedQuestion: "در حرکت از کارشناس ارشد به مدیر میانی، بیشترین تغییر در نوع پاسخ‌گویی تو چه بود؟",
    answer:
      "مسئولیت از انجام دقیق تحلیل به ساختن چارچوب تصمیم منتقل شد. باید مطمئن می‌شدم تیم می‌تواند بدون حضور دائمی من تصمیم‌های کوچک درست بگیرد. این تغییر بیشتر رفتاری بود تا فقط تغییر عنوان شغلی.",
    status: "published",
    publishedAt: "2026-05-12T09:00:00.000Z"
  },
  {
    id: "answer-published-1",
    profileId: "ali",
    questionId: "published-q-1",
    renderedQuestion: "در نقش مدیر محصول، چه چیزی واقعاً جزو اختیار توست و چه چیزی فقط ظاهراً به نقش تو مربوط است؟",
    answer:
      "اختیار واقعی من در شفاف کردن مسئله و ساختن اولویت‌هاست. اما خیلی از تصمیم‌ها بدون هم‌راستایی با عملیات، داده و طراحی پیش نمی‌رود. نقش محصول بیشتر از چیزی که از بیرون دیده می‌شود به اعتمادسازی وابسته است.",
    status: "published",
    publishedAt: "2026-05-02T09:00:00.000Z"
  },
  {
    id: "answer-retracted-1",
    profileId: "ali",
    questionId: "published-q-0",
    renderedQuestion: "در نقش مدیر محصول، سخت‌ترین بخش کار مهارت تخصصی نیست؛ پس چیست؟",
    answer: "این پاسخ از پروفایل حذف شده است.",
    status: "retracted",
    publishedAt: "2026-04-22T09:00:00.000Z"
  }
];

export const weeklyQuestionNotification = {
  id: "notification-weekly-question",
  title: weeklyQuestionCopy.notificationTitle,
  body: "برای پاسخ دادن به پرسش کوتاه هفتگی وارد پروفایل خودت شو.",
  targetRoute: weeklyQuestionCopy.notificationTarget
};

export function deriveQuestionFieldsFromTimeline(timeline: readonly ExperienceTimelineItem[], profileJobFields: readonly string[] = []) {
  void profileJobFields;
  const current = getCurrentTimelineItem(timeline);
  const previous = getPreviousTimelineItem(timeline);
  const currentJobField = current?.jobField && isValidJobField(current.jobField) ? current.jobField : null;

  return {
    current_role: current?.jobTitle || undefined,
    current_seniority: current?.orgLevel || undefined,
    current_company: current?.companyName || undefined,
    current_company_country: current?.companyCountry || undefined,
    previous_role: previous?.jobTitle || undefined,
    previous_seniority: previous?.orgLevel || undefined,
    previous_company: previous?.companyName || undefined,
    job_category: currentJobField ?? undefined
  } satisfies QuestionFieldMapping;
}

export function renderExperienceQuestion(template: ExperienceQuestionTemplate, fields: QuestionFieldMapping) {
  return template.templateText.replace(/\{([a-z_]+)\}/g, (_, key: keyof QuestionFieldMapping) => fields[key] ?? "");
}

export function templateIsEligible(template: ExperienceQuestionTemplate, fields: QuestionFieldMapping) {
  return template.requiredFields.every((field) => Boolean(fields[field]));
}

export function getEligibleQuestionTemplates(fields: QuestionFieldMapping) {
  return experienceQuestionTemplates.filter((template) => templateIsEligible(template, fields));
}

export function getActiveWeeklyQuestion(timeline: readonly ExperienceTimelineItem[], profileJobFields: readonly string[] = []) {
  const fields = deriveQuestionFieldsFromTimeline(timeline, profileJobFields);
  const template = getEligibleQuestionTemplates(fields)[0] ?? null;

  if (!template) {
    return null;
  }

  return {
    id: "weekly-question-current",
    templateId: template.id,
    status: "active",
    renderedQuestion: renderExperienceQuestion(template, fields)
  } satisfies ExperienceQuestion;
}

export function publishExperienceAnswer(answer: ExperienceAnswer, responsibilityAccepted: boolean) {
  if (!responsibilityAccepted || !answer.answer.trim()) {
    return {
      answer,
      published: false,
      error: weeklyQuestionCopy.responsibilityText
    };
  }

  return {
    answer: {
      ...answer,
      status: "published" as ExperienceAnswerStatus,
      publishedAt: answer.publishedAt ?? "2026-05-22T12:00:00.000Z"
    },
    published: true,
    error: ""
  };
}

export function retractExperienceAnswer(answer: ExperienceAnswer) {
  return {
    ...answer,
    status: "retracted" as ExperienceAnswerStatus
  };
}

export function getPublishedProfileAnswers(profileId: string, answers: readonly ExperienceAnswer[] = initialExperienceAnswers) {
  return answers
    .filter((answer) => answer.profileId === profileId && answer.status === "published")
    .sort((a, b) => String(b.publishedAt).localeCompare(String(a.publishedAt)))
    .slice(0, 3);
}
