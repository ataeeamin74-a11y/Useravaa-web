"use client";

import { useEffect, useState } from "react";
import {
  profileBuilderDraftStorageKey,
  profileFromBuilderDraft,
  transitionProfileStatus,
  type MyExperienceProfile,
  type MyProfileDashboardFixture,
  type ProfileBuilderDraft
} from "@/features/v51/data/my-profile";
import { getActiveWeeklyQuestion } from "@/features/v51/data/experience-questions";
import { ProfileDashboardPanels } from "../components/ProfileDashboardPanels";
import { ProfileStatusCard } from "../components/ProfileStatusCard";
import { WeeklyQuestionCard } from "../components/WeeklyQuestionCard";
import styles from "../components/MyProfile.module.css";

type ProfileDashboardClientProps = {
  fixture: MyProfileDashboardFixture;
};

export function ProfileDashboardClient({ fixture }: ProfileDashboardClientProps) {
  const [status, setStatus] = useState(fixture.status);
  const [profile, setProfile] = useState<MyExperienceProfile>(fixture.profile);
  const [message, setMessage] = useState("");
  const dashboard = { ...fixture, status, profile };
  const activeQuestion = getActiveWeeklyQuestion(profile.experienceTimeline, profile.jobCategoriesFa);

  useEffect(() => {
    let storedProfile: MyExperienceProfile | null = null;

    try {
      const storedDraft = window.localStorage.getItem(profileBuilderDraftStorageKey);

      if (storedDraft) {
        storedProfile = profileFromBuilderDraft(JSON.parse(storedDraft) as ProfileBuilderDraft);
      }
    } catch {
      window.localStorage.removeItem(profileBuilderDraftStorageKey);
    }

    window.queueMicrotask(() => {
      if (storedProfile) {
        setProfile(storedProfile);
      }
    });
  }, []);

  const deactivateProfile = () => {
    const confirmed = typeof window === "undefined" ? true : window.confirm("پروفایل تجربه موقتاً غیرفعال شود؟");

    if (!confirmed) {
      return;
    }

    setStatus((current) => transitionProfileStatus(current, "deactivate_profile"));
    setMessage("پروفایل تجربه غیرفعال شد.");
  };

  const reactivateProfile = () => {
    setStatus((current) => transitionProfileStatus(current, "reactivate_requires_review"));
    setMessage("پروفایل تجربه برای بررسی دوباره ارسال شد.");
  };

  return (
    <>
      <ProfileStatusCard status={status} incomingRequests={fixture.incomingRequests} onDeactivate={deactivateProfile} onReactivate={reactivateProfile} />
      {message ? (
        <p className={styles.statusMessage} role="status" aria-live="polite">
          {message}
        </p>
      ) : null}
      <WeeklyQuestionCard question={activeQuestion} />
      <ProfileDashboardPanels fixture={dashboard} />
    </>
  );
}
