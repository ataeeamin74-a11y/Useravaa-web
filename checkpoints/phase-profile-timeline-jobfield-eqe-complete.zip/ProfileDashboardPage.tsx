import { getDashboardFixture, type MyProfileDashboardFixture } from "@/features/v51/data/my-profile";
import styles from "../components/MyProfile.module.css";
import { ProfileDashboardClient } from "./ProfileDashboardClient";

type ProfileDashboardPageProps = {
  fixture?: MyProfileDashboardFixture;
  state?: string | null;
};

export function ProfileDashboardPage({ fixture, state }: ProfileDashboardPageProps) {
  const dashboard = fixture ?? getDashboardFixture(state);

  return (
    <div className={styles.dashboardShell}>
      <section className={styles.hero}>
        <div>
          <h1>پروفایل من</h1>
          <p className={styles.lead}>پروفایل تجربه، شبکه حرفه‌ای، بازخوردها و تنظیمات حسابت را اینجا مدیریت کن.</p>
        </div>
      </section>

      <ProfileDashboardClient fixture={dashboard} />
    </div>
  );
}
