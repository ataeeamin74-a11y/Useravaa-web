import { V51LinkButton } from "@/features/v51/components/V51Button";
import { weeklyQuestionNotification } from "@/features/v51/data/experience-questions";
import styles from "./NotificationsPage.module.css";

export function NotificationsPage() {
  return (
    <section className={styles.notificationsShell}>
      <h1>اعلان‌ها</h1>
      <p className={styles.lead}>یادآوری‌های مهم حساب و پروفایل تجربه.</p>

      <article className={styles.notificationCard}>
        <div>
          <b>{weeklyQuestionNotification.title}</b>
          <p>{weeklyQuestionNotification.body}</p>
        </div>
        <V51LinkButton href={weeklyQuestionNotification.targetRoute} tone="primary">
          رفتن به پرسش
        </V51LinkButton>
      </article>
    </section>
  );
}
