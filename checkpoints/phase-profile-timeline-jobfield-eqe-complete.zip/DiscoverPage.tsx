"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { V51Button } from "@/features/v51/components/V51Button";
import { isValidJobField } from "@/features/v51/data/job-fields";
import {
  categoryOptions,
  companyOptions,
  formatter,
  toggleProfileIdSelection,
  profiles,
  roleOptions,
  toFaDecimal,
  type DiscoveryState,
  type ExperienceProfileFixture,
  type ExperienceRange,
  type SortOption
} from "@/features/v51/data/profiles";
import styles from "./DiscoverPage.module.css";

type DiscoverPageProps = Readonly<{
  initialState: DiscoveryState;
}>;

type Filters = {
  query: string;
  role: string;
  category: string;
  level: string;
  company: string;
  experience: ExperienceRange;
  language: string;
  sort: SortOption;
};

const emptyFilters: Filters = {
  query: "",
  role: "",
  category: "",
  level: "",
  company: "",
  experience: "",
  language: "",
  sort: "relevant"
};

const experienceLabels: Record<ExperienceRange, string> = {
  "": "همه سابقه‌ها",
  "0-2": "۰ تا ۲ سال",
  "3-5": "۳ تا ۵ سال",
  "6-9": "۶ تا ۹ سال",
  "10-14": "۱۰ تا ۱۴ سال",
  "15+": "۱۵ سال و بیشتر"
};

function classNames(...classes: Array<string | false | undefined>) {
  return classes.filter(Boolean).join(" ");
}

function yearsInRange(years: number, range: ExperienceRange) {
  if (!range) {
    return true;
  }

  if (range === "0-2") {
    return years >= 0 && years <= 2;
  }

  if (range === "3-5") {
    return years >= 3 && years <= 5;
  }

  if (range === "6-9") {
    return years >= 6 && years <= 9;
  }

  if (range === "10-14") {
    return years >= 10 && years <= 14;
  }

  return years >= 15;
}

function profileMatches(profile: ExperienceProfileFixture, filters: Filters) {
  const haystack = [
    profile.name,
    profile.roleFa,
    profile.orgLevel,
    profile.professionalSummary,
    ...profile.previousCompaniesFa,
    ...profile.jobCategoriesFa
  ]
    .join(" ")
    .toLowerCase();
  const query = filters.query.trim().toLowerCase();

  return (
    (!query || haystack.includes(query)) &&
    (!filters.role || profile.roleFa === filters.role) &&
    (!filters.category || (isValidJobField(filters.category) && profile.jobCategoriesFa.includes(filters.category))) &&
    (!filters.level || profile.orgLevel === filters.level) &&
    (!filters.company || profile.previousCompaniesFa.includes(filters.company)) &&
    yearsInRange(profile.yearsOfExperience, filters.experience) &&
    (!filters.language || profile.languages.includes(filters.language))
  );
}

function sortProfiles(items: readonly ExperienceProfileFixture[], sort: SortOption) {
  const sorted = [...items];

  if (sort === "experience_desc") {
    sorted.sort((a, b) => b.yearsOfExperience - a.yearsOfExperience);
  }

  if (sort === "csat_desc") {
    sorted.sort((a, b) => (b.csat ?? 0) - (a.csat ?? 0));
  }

  if (sort === "recent_activity") {
    sorted.sort((a, b) => a.lastActiveDays - b.lastActiveDays);
  }

  return sorted;
}

function BookmarkIcon() {
  return (
    <svg viewBox="0 0 24 24" aria-hidden="true">
      <path d="M7 4.75C7 3.78 7.78 3 8.75 3h6.5C16.22 3 17 3.78 17 4.75V21l-5-3-5 3V4.75Z" />
    </svg>
  );
}

function SkeletonCards() {
  return (
    <div className={classNames(styles.skeletonGrid, styles.show)} aria-live="polite" aria-label="در حال بارگذاری تجربه‌ها">
      {Array.from({ length: 8 }).map((_, index) => (
        <div className={styles.skeletonCard} key={index}>
          <div className={styles.skeletonAvatar} />
          <div className={classNames(styles.skeletonLine, styles.medium)} />
          <div className={classNames(styles.skeletonLine, styles.short)} />
          <span className={styles.skeletonChip} />
          <span className={styles.skeletonChip} />
          <span className={styles.skeletonChip} />
          <div className={styles.skeletonLine} />
          <div className={classNames(styles.skeletonLine, styles.medium)} />
          <span className={styles.skeletonButton} />
          <span className={styles.skeletonButton} />
        </div>
      ))}
    </div>
  );
}

export function DiscoverPage({ initialState }: DiscoverPageProps) {
  const [filters, setFilters] = useState<Filters>(emptyFilters);
  const [discoveryState, setDiscoveryState] = useState<DiscoveryState>(initialState);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [savedProfileIds, setSavedProfileIds] = useState(() => new Set<string>());
  const [followedProfileIds, setFollowedProfileIds] = useState(() => new Set<string>());
  const [toastMessage, setToastMessage] = useState("");
  const toastTimeout = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (toastTimeout.current) {
        window.clearTimeout(toastTimeout.current);
      }
    };
  }, []);

  const results = useMemo(() => {
    return sortProfiles(
      profiles.filter((profile) => profileMatches(profile, filters)),
      filters.sort
    );
  }, [filters]);

  const activeFilters = useMemo(() => {
    const items: Array<{ key: keyof Filters; label: string }> = [];

    if (filters.query.trim()) {
      items.push({ key: "query", label: `جستجو: ${filters.query.trim()}` });
    }

    if (filters.role) {
      items.push({ key: "role", label: filters.role });
    }

    if (filters.category) {
      items.push({ key: "category", label: filters.category });
    }

    if (filters.level) {
      items.push({ key: "level", label: filters.level });
    }

    if (filters.company) {
      items.push({ key: "company", label: filters.company });
    }

    if (filters.experience) {
      items.push({ key: "experience", label: experienceLabels[filters.experience] });
    }

    if (filters.language) {
      items.push({ key: "language", label: filters.language });
    }

    return items;
  }, [filters]);

  function updateFilter<TKey extends keyof Filters>(key: TKey, value: Filters[TKey]) {
    setFilters((current) => ({ ...current, [key]: value }));
  }

  function removeFilter(key: keyof Filters) {
    setFilters((current) => ({ ...current, [key]: emptyFilters[key] }));
    setIsDrawerOpen(false);
  }

  function clearAllFilters() {
    setFilters(emptyFilters);
    setIsDrawerOpen(false);
  }

  function toggleSetValue(setter: typeof setSavedProfileIds, profileId: string) {
    setter((current) => toggleProfileIdSelection(current, profileId));
  }

  function showToast(message: string) {
    setToastMessage(message);

    if (toastTimeout.current) {
      window.clearTimeout(toastTimeout.current);
    }

    toastTimeout.current = window.setTimeout(() => setToastMessage(""), 2200);
  }

  function toggleSavedProfile(profileId: string) {
    const willBeSaved = !savedProfileIds.has(profileId);
    toggleSetValue(setSavedProfileIds, profileId);
    showToast(willBeSaved ? "برای بعد ذخیره شد." : "از ذخیره‌شده‌ها حذف شد.");
  }

  function toggleFollowedProfile(profileId: string) {
    const willBeFollowed = !followedProfileIds.has(profileId);
    toggleSetValue(setFollowedProfileIds, profileId);
    showToast(willBeFollowed ? "دنبال شد." : "از دنبال‌شده‌ها حذف شد.");
  }

  const activeFilterCount = activeFilters.length;

  return (
    <section>
      <div
        className={classNames(styles.drawerScrim, isDrawerOpen && styles.drawerScrimOpen)}
        aria-hidden="true"
        onClick={() => setIsDrawerOpen(false)}
      />

      <div className={styles.discoverHero}>
        <h1>کشف تجربه‌ها</h1>
        <p className={styles.lead}>آدم‌هایی را پیدا کن که تجربه کاری‌شان به تصمیم شغلی تو کمک می‌کند.</p>
        <div className={styles.heroLinkRow}>
          <Link className={styles.howLink} href="/guide">
            راهنمای Useravaa
          </Link>
        </div>
      </div>

      <div className={styles.mobileFilterActions}>
        <button className={styles.mobileFilterButton} type="button" onClick={() => setIsDrawerOpen(true)}>
          فیلترها
          <span className={classNames(styles.mobileFilterCount, activeFilterCount > 0 && styles.show)}>
            {formatter.format(activeFilterCount)}
          </span>
        </button>
      </div>

      <div className={classNames(styles.filterShell, isDrawerOpen && styles.filterShellOpen)} aria-label="فیلترها">
        <div className={styles.mobileFilterHeader}>
          <strong>فیلترها</strong>
          <button type="button" onClick={() => setIsDrawerOpen(false)}>
            بستن
          </button>
        </div>
        <div className={styles.filterGrid}>
          <span className={classNames(styles.field, styles.search, filters.query && styles.active)}>
            <span className={styles.searchIcon}>⌕</span>
            <input
              type="search"
              placeholder="جستجو براساس نقش، حوزه شغلی یا شرکت"
              value={filters.query}
              onChange={(event) => updateFilter("query", event.target.value)}
            />
          </span>

          <span className={classNames(styles.field, filters.role && styles.active)}>
            <select aria-label="نقش" value={filters.role} onChange={(event) => updateFilter("role", event.target.value)}>
              <option value="">همه نقش‌ها</option>
              {roleOptions.map((role) => (
                <option key={role}>{role}</option>
              ))}
            </select>
            <span className={styles.caret}>⌄</span>
          </span>

          <span className={classNames(styles.field, filters.category && styles.active)}>
            <select
              aria-label="حوزه شغلی"
              value={filters.category}
              onChange={(event) => updateFilter("category", event.target.value)}
            >
              <option value="">همه حوزه‌های شغلی</option>
              {categoryOptions.map((category) => (
                <option key={category}>{category}</option>
              ))}
            </select>
            <span className={styles.caret}>⌄</span>
          </span>

          <span className={classNames(styles.field, filters.level && styles.active)}>
            <select aria-label="رده سازمانی" value={filters.level} onChange={(event) => updateFilter("level", event.target.value)}>
              <option value="">همه رده‌ها</option>
              <option>کارآموز</option>
              <option>کارشناس</option>
              <option>کارشناس ارشد</option>
              <option>مدیر میانی</option>
              <option>مدیر ارشد</option>
              <option>معاونت</option>
            </select>
            <span className={styles.caret}>⌄</span>
          </span>

          <span className={classNames(styles.field, filters.company && styles.active)}>
            <select
              aria-label="شرکت‌های قبلی"
              value={filters.company}
              onChange={(event) => updateFilter("company", event.target.value)}
            >
              <option value="">همه شرکت‌ها</option>
              {companyOptions.map((company) => (
                <option key={company}>{company}</option>
              ))}
            </select>
            <span className={styles.caret}>⌄</span>
          </span>

          <span className={classNames(styles.field, filters.experience && styles.active)}>
            <select
              aria-label="سابقه کار"
              value={filters.experience}
              onChange={(event) => updateFilter("experience", event.target.value as ExperienceRange)}
            >
              {Object.entries(experienceLabels).map(([value, label]) => (
                <option key={value || "all"} value={value}>
                  {label}
                </option>
              ))}
            </select>
            <span className={styles.caret}>⌄</span>
          </span>

          <span className={classNames(styles.field, filters.language && styles.active)}>
            <select
              aria-label="زبان گفت‌وگو"
              value={filters.language}
              onChange={(event) => updateFilter("language", event.target.value)}
            >
              <option value="">همه زبان‌ها</option>
              <option>فارسی</option>
              <option>انگلیسی</option>
            </select>
            <span className={styles.caret}>⌄</span>
          </span>
        </div>
      </div>

      <div className={classNames(styles.activeFilterRow, activeFilterCount > 0 && styles.showFlex)}>
        <div className={styles.activeFilterList}>
          <span className={styles.activeLabel}>فیلترهای فعال:</span>
          {activeFilters.map((item) => (
            <span className={styles.activeChip} key={item.key}>
              {item.label}
              <button type="button" aria-label={`حذف ${item.label}`} onClick={() => removeFilter(item.key)}>
                ×
              </button>
            </span>
          ))}
        </div>
        <button className={styles.clearAll} type="button" onClick={clearAllFilters}>
          پاک کردن همه
        </button>
      </div>

      <div className={styles.resultsMeta}>
        <div className={styles.resultCount}>
          {discoveryState === "loading" ? "در حال بارگذاری.." : results.length ? `${formatter.format(results.length)} نتیجه` : ""}
        </div>
        <div className={styles.sortBox}>
          <span>مرتب‌سازی:</span>
          <span className={styles.sortControl}>
            <select
              aria-label="مرتب‌سازی"
              value={filters.sort}
              onChange={(event) => updateFilter("sort", event.target.value as SortOption)}
            >
              <option value="relevant">مرتبط‌ترین</option>
              <option value="experience_desc">بیشترین سابقه</option>
              <option value="csat_desc">بالاترین رضایت</option>
              <option value="recent_activity">جدیدترین فعالیت</option>
            </select>
            <span className={styles.caret}>⌄</span>
          </span>
        </div>
      </div>

      {discoveryState === "loading" ? <SkeletonCards /> : null}

      {discoveryState === "error" ? (
        <div className={classNames(styles.statePanel, styles.showBlock)} role="alert">
          <h2>نتایج بارگذاری نشد.</h2>
          <p className={styles.lead}>اتصال را بررسی کن یا دوباره تلاش کن.</p>
          <V51Button tone="primary" onClick={() => setDiscoveryState("ready")}>
            تلاش دوباره
          </V51Button>
        </div>
      ) : null}

      {discoveryState === "ready" ? (
        <>
          <div className={styles.grid}>
            {results.map((profile) => {
              const isSaved = savedProfileIds.has(profile.id);
              const isFollowing = followedProfileIds.has(profile.id);

              return (
                <article className={styles.card} aria-label={`کارت تجربه ${profile.name}، ${profile.roleFa}`} key={profile.id}>
                  <button
                    className={classNames(styles.bookmark, isSaved && styles.saved)}
                    aria-label="ذخیره برای بعد"
                    type="button"
                    onClick={() => toggleSavedProfile(profile.id)}
                  >
                    <BookmarkIcon />
                  </button>

                  <header className={styles.head}>
                    <div className={styles.avatar}>{profile.initials}</div>
                    <div className={styles.identity}>
                      <h3 className={styles.name}>{profile.name}</h3>
                      <p className={styles.role}>{profile.roleFa}</p>
                    </div>
                  </header>

                  <div className={styles.trust}>
                    <span className={classNames(styles.chip, styles.level)}>{profile.orgLevel}</span>
                    <span className={styles.chip}>{formatter.format(profile.yearsOfExperience)} سال</span>
                    {profile.csat ? (
                      <span className={classNames(styles.chip, styles.csat)} aria-label={`رضایت گفت‌وگوها ${toFaDecimal(profile.csat)} از ۵`}>
                        <span className={styles.star}>★</span>
                        {toFaDecimal(profile.csat)}
                      </span>
                    ) : null}
                  </div>

                  <div className={styles.inlineTaxonomy}>
                    {profile.jobCategoriesFa.slice(0, 3).join(" · ")}
                    {profile.jobCategoriesFa.length > 3 ? ` +${formatter.format(profile.jobCategoriesFa.length - 3)}` : ""}
                  </div>
                  {profile.previousCompaniesFa.length ? <div className={styles.companies}>{profile.previousCompaniesFa.join(" · ")}</div> : null}
                  <p className={styles.summary}>{profile.professionalSummary}</p>

                  <div className={styles.divider} />

                  <div className={styles.actions}>
                    <button
                      className={classNames(styles.cta, styles.secondary)}
                      aria-pressed={isFollowing}
                      type="button"
                      onClick={() => toggleFollowedProfile(profile.id)}
                    >
                      {isFollowing ? "دنبال‌شده" : "دنبال کردن"}
                    </button>
                    <Link className={classNames(styles.cta, styles.primary)} href={`/profiles/${profile.id}`}>
                      دیدن تجربه
                    </Link>
                  </div>
                </article>
              );
            })}
          </div>

          {!results.length ? (
            <div className={styles.empty}>
              <h2>با این فیلترها نتیجه‌ای پیدا نشد.</h2>
              <p className={styles.lead}>فیلترها را بازتر کن یا عبارت جستجو را تغییر بده.</p>
              <V51Button tone="primary" onClick={clearAllFilters}>
                پاک کردن فیلترها
              </V51Button>
            </div>
          ) : null}
        </>
      ) : null}
      <div className={classNames(styles.toast, toastMessage && styles.toastShow)} role="status" aria-live="polite">
        {toastMessage}
      </div>
    </section>
  );
}
