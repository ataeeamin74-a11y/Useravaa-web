import { ProfileBuilderPage } from "@/features/v51/my-profile/pages/ProfileBuilderPage";

export default function ProfileBuildRoute() {
  return <ProfileBuilderPage />;
}
