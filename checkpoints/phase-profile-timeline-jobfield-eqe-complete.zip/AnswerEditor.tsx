import { weeklyQuestionCopy } from "@/features/v51/data/experience-questions";
import styles from "./MyProfile.module.css";

type AnswerEditorProps = Readonly<{
  value: string;
  onChange: (value: string) => void;
}>;

export function AnswerEditor({ value, onChange }: AnswerEditorProps) {
  return (
    <div className={`${styles.field} ${styles.fieldFull}`}>
      <label htmlFor="weeklyQuestionAnswer">پاسخ شما</label>
      <textarea
        id="weeklyQuestionAnswer"
        value={value}
        placeholder="پاسخ کوتاه و حرفه‌ای خود را بنویسید."
        onChange={(event) => onChange(event.target.value)}
      />
      <small className={styles.helperText}>{weeklyQuestionCopy.answerHelper}</small>
    </div>
  );
}
