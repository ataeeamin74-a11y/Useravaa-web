"use client";

import { useState } from "react";
import { V51Button } from "@/features/v51/components/V51Button";
import {
  publishExperienceAnswer,
  retractExperienceAnswer,
  weeklyQuestionCopy,
  type ExperienceAnswer,
  type ExperienceQuestion
} from "@/features/v51/data/experience-questions";
import { AnswerEditor } from "./AnswerEditor";
import { ResponsibilityCheckbox } from "./ResponsibilityCheckbox";
import { RetractAnswerButton } from "./RetractAnswerButton";
import styles from "./MyProfile.module.css";

type WeeklyQuestionCardProps = Readonly<{
  question: ExperienceQuestion | null;
}>;

export function WeeklyQuestionCard({ question }: WeeklyQuestionCardProps) {
  const [mode, setMode] = useState<"idle" | "answering" | "published" | "skipped">(question ? "idle" : "skipped");
  const [answerText, setAnswerText] = useState("");
  const [responsibilityAccepted, setResponsibilityAccepted] = useState(false);
  const [publishedAnswer, setPublishedAnswer] = useState<ExperienceAnswer | null>(null);
  const [message, setMessage] = useState("");

  if (!question) {
    return (
      <section id="weekly-question" className={styles.weeklyQuestionCard} aria-labelledby="weeklyQuestionTitle">
        <div className={styles.sectionHead}>
          <div>
            <h2 id="weeklyQuestionTitle">{weeklyQuestionCopy.title}</h2>
            <p>{weeklyQuestionCopy.description}</p>
          </div>
        </div>
        <p className={styles.inlineNote}>برای دریافت پرسش این هفته، عنوان شغلی فعلی را در سوابق تجربه کامل کن.</p>
      </section>
    );
  }

  const draftAnswer: ExperienceAnswer = {
    id: "weekly-answer-draft",
    profileId: "ali",
    questionId: question.id,
    renderedQuestion: question.renderedQuestion,
    answer: answerText,
    status: "draft",
    publishedAt: null
  };

  const publish = () => {
    const result = publishExperienceAnswer(draftAnswer, responsibilityAccepted);

    if (!result.published) {
      setMessage(result.error);
      return;
    }

    setPublishedAnswer(result.answer);
    setMode("published");
    setMessage("پاسخ در پروفایل منتشر شد.");
  };

  const retract = () => {
    if (!publishedAnswer) {
      return;
    }

    setPublishedAnswer(retractExperienceAnswer(publishedAnswer));
    setMode("idle");
    setAnswerText("");
    setResponsibilityAccepted(false);
    setMessage("پاسخ از پروفایل حذف شد.");
  };

  return (
    <section id="weekly-question" className={styles.weeklyQuestionCard} aria-labelledby="weeklyQuestionTitle">
      <div className={styles.sectionHead}>
        <div>
          <h2 id="weeklyQuestionTitle">{weeklyQuestionCopy.title}</h2>
          <p>{weeklyQuestionCopy.description}</p>
        </div>
      </div>

      {mode !== "published" ? <p className={styles.weeklyQuestionText}>{question.renderedQuestion}</p> : null}

      {mode === "idle" ? (
        <div className={styles.actions}>
          <V51Button type="button" tone="primary" onClick={() => setMode("answering")}>
            {weeklyQuestionCopy.answerAction}
          </V51Button>
          <V51Button type="button" onClick={() => setMessage("سؤال جدیدی برای همین هفته آماده شد.")}>
            {weeklyQuestionCopy.replaceAction}
          </V51Button>
          <V51Button type="button" onClick={() => setMode("skipped")}>
            {weeklyQuestionCopy.skipAction}
          </V51Button>
        </div>
      ) : null}

      {mode === "answering" ? (
        <div className={styles.answerEditor}>
          <AnswerEditor value={answerText} onChange={setAnswerText} />
          <ResponsibilityCheckbox checked={responsibilityAccepted} onChange={setResponsibilityAccepted} />
          <div className={styles.actions}>
            <V51Button type="button" tone="primary" disabled={!responsibilityAccepted || !answerText.trim()} onClick={publish}>
              {weeklyQuestionCopy.publishAction}
            </V51Button>
            <V51Button type="button" onClick={() => setMode("idle")}>
              انصراف
            </V51Button>
          </div>
        </div>
      ) : null}

      {mode === "published" && publishedAnswer?.status === "published" ? (
        <article className={styles.publishedAnswerCard}>
          <b>{publishedAnswer.renderedQuestion}</b>
          <p>{publishedAnswer.answer}</p>
          <RetractAnswerButton onRetract={retract} />
        </article>
      ) : null}

      {mode === "skipped" ? <p className={styles.inlineNote}>فعلاً این پرسش کنار گذاشته شد.</p> : null}
      {message ? <p className={styles.statusMessage}>{message}</p> : null}
    </section>
  );
}
