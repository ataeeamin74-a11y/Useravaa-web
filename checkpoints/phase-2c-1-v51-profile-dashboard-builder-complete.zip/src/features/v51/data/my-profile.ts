import { formatter, toFaDecimal, toman } from "./profiles";

export type ExperienceProfileStatus = "none" | "draft" | "pending_review" | "needs_changes" | "active" | "inactive";

export type OrgLevel =
  | "کارآموز"
  | "کارشناس"
  | "کارشناس ارشد"
  | "مدیر میانی"
  | "مدیر ارشد"
  | "معاونت"
  | "مدیر کسب و کار";

export type ProfileBuilderDraft = {
  displayName: string;
  role: string;
  orgLevel: OrgLevel;
  years: number;
  categories: string[];
  companies: string[];
  languages: string[];
  summary: string;
  price30: number;
  price60: number;
  freeHelp: boolean;
  avatarUrl: string;
};

export type MyExperienceProfile = {
  name: string;
  initials: string;
  roleFa: string;
  orgLevel: OrgLevel;
  yearsOfExperience: number;
  jobCategoriesFa: string[];
  previousCompaniesFa: string[];
  languages: string[];
  professionalSummary: string;
  pricing: {
    30: number;
    60: number;
  };
  freeHelp: boolean;
  avatarUrl?: string;
};

export type MyProfileDashboardFixture = {
  status: ExperienceProfileStatus;
  profile: MyExperienceProfile;
  incomingRequests: number;
  network: {
    following: number;
    saved: number;
    followers: number;
  };
  stats: {
    successfulConversations: number;
    csat: number;
    profileViews: number;
    availableEarnings: number;
  };
  feedbackCount: number;
  account: {
    name: string;
    email: string;
  };
  settlement: {
    iban: string | null;
  };
};

export type ProfileValidationErrors = Partial<
  Record<"displayName" | "role" | "years" | "categories" | "companies" | "languages" | "summary" | "price30" | "price60", string>
>;

export type ProfileStatusAction = "submit_for_review" | "resubmit_for_review" | "deactivate_profile" | "reactivate_requires_review" | "submit_material_changes";

export const orgLevels: OrgLevel[] = ["کارآموز", "کارشناس", "کارشناس ارشد", "مدیر میانی", "مدیر ارشد", "معاونت", "مدیر کسب و کار"];

export const builderCategories = ["محصول", "هوش تجاری", "تحلیل داده", "طراحی محصول", "رشد", "منابع انسانی", "مهندسی"];

export const builderLanguages = ["فارسی", "انگلیسی"];

export const companySuggestions = ["اسنپ", "دیجی‌کالا", "کافه‌بازار", "دیوار"];

export const pricingCapsByLevel: Record<OrgLevel, { 30: number; 60: number }> = {
  کارآموز: { 30: 100000, 60: 250000 },
  کارشناس: { 30: 300000, 60: 500000 },
  "کارشناس ارشد": { 30: 500000, 60: 900000 },
  "مدیر میانی": { 30: 1000000, 60: 1800000 },
  "مدیر ارشد": { 30: 1000000, 60: 1800000 },
  معاونت: { 30: 2500000, 60: 4000000 },
  "مدیر کسب و کار": { 30: 4000000, 60: 7000000 }
};

export const initialBuilderDraft: ProfileBuilderDraft = {
  displayName: "علی ر.",
  role: "مدیر محصول",
  orgLevel: "مدیر میانی",
  years: 8,
  categories: ["محصول", "هوش تجاری", "تحلیل داده"],
  companies: ["اسنپ", "دیجی‌کالا"],
  languages: ["فارسی"],
  summary: "تجربه در تیم‌های محصول و تحلیل داده، با تمرکز بر تصمیم‌سازی محصولی.",
  price30: 1000000,
  price60: 1800000,
  freeHelp: false,
  avatarUrl: ""
};

export const myProfileDashboardFixture: MyProfileDashboardFixture = {
  status: "active",
  profile: {
    name: "علی ر.",
    initials: "ع",
    roleFa: "مدیر محصول",
    orgLevel: "مدیر میانی",
    yearsOfExperience: 8,
    jobCategoriesFa: ["محصول", "هوش تجاری", "تحلیل داده"],
    previousCompaniesFa: ["اسنپ", "دیجی‌کالا"],
    languages: ["فارسی"],
    professionalSummary: "تجربه در تیم‌های محصول و تحلیل داده، با تمرکز بر تصمیم‌سازی محصولی.",
    pricing: { 30: 1000000, 60: 1800000 },
    freeHelp: false
  },
  incomingRequests: 2,
  network: {
    following: 1,
    saved: 1,
    followers: 212
  },
  stats: {
    successfulConversations: 42,
    csat: 4.8,
    profileViews: 248,
    availableEarnings: 1800000
  },
  feedbackCount: 3,
  account: {
    name: "علی ر.",
    email: "user@example.com"
  },
  settlement: {
    iban: "IR••••••••••••••••۴۲۱"
  }
};

export function getDashboardFixture(status?: string | null): MyProfileDashboardFixture {
  const normalized = normalizeProfileStatus(status);
  return {
    ...myProfileDashboardFixture,
    status: normalized
  };
}

export function normalizeProfileStatus(status?: string | null): ExperienceProfileStatus {
  if (status === "none" || status === "draft" || status === "pending_review" || status === "needs_changes" || status === "active" || status === "inactive") {
    return status;
  }

  return "active";
}

export function statusCopy(status: ExperienceProfileStatus) {
  const copy: Record<ExperienceProfileStatus, { tone: string; badge: string; title: string; body: string }> = {
    none: {
      tone: "none",
      badge: "پروفایل ساخته نشده",
      title: "پروفایل تجربه‌ات را بساز",
      body: "پروفایل تجربه بساز تا دیگران بتوانند برای گفت‌وگو به تو درخواست بدهند."
    },
    draft: {
      tone: "none",
      badge: "پیش‌نویس",
      title: "پروفایل تجربه‌ات را بساز",
      body: "اطلاعات را کامل کن و برای بررسی بفرست."
    },
    pending_review: {
      tone: "pending",
      badge: "در انتظار بررسی",
      title: "پروفایل تجربه تو در انتظار بررسی است",
      body: "بعد از تأیید، در کشف تجربه‌ها دیده می‌شوی."
    },
    needs_changes: {
      tone: "pending",
      badge: "نیازمند اصلاح",
      title: "پروفایل تجربه نیازمند اصلاح است",
      body: "اگر موردی نیاز به تغییر داشته باشد، اطلاعات را اصلاح کن و دوباره برای بررسی بفرست."
    },
    inactive: {
      tone: "inactive",
      badge: "غیرفعال",
      title: "پروفایل تجربه تو غیرفعال است",
      body: "فعلاً در کشف تجربه‌ها دیده نمی‌شوی."
    },
    active: {
      tone: "active",
      badge: "فعال در کشف تجربه‌ها",
      title: "پروفایل تجربه تو فعال است",
      body: "در کشف تجربه‌ها دیده می‌شوی."
    }
  };

  return copy[status];
}

export function transitionProfileStatus(status: ExperienceProfileStatus, action: ProfileStatusAction): ExperienceProfileStatus {
  if (status === "draft" && action === "submit_for_review") {
    return "pending_review";
  }

  if (status === "needs_changes" && action === "resubmit_for_review") {
    return "pending_review";
  }

  if (status === "active" && action === "deactivate_profile") {
    return "inactive";
  }

  if (status === "inactive" && action === "reactivate_requires_review") {
    return "pending_review";
  }

  if (status === "active" && action === "submit_material_changes") {
    return "pending_review";
  }

  return status;
}

export function addCompanyTag(companies: string[], name: string) {
  const clean = name.trim();
  return !clean || companies.includes(clean) ? companies : [...companies, clean];
}

export function removeCompanyTag(companies: string[], name: string) {
  return companies.filter((item) => item !== name);
}

export function toggleSelection(items: string[], item: string) {
  return items.includes(item) ? items.filter((current) => current !== item) : [...items, item];
}

export function validateAvatarCandidate(file: { type: string; size: number } | null | undefined) {
  if (!file) {
    return "";
  }

  if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
    return "فرمت عکس باید PNG، JPG یا WebP باشد.";
  }

  if (file.size > 2 * 1024 * 1024) {
    return "حجم عکس نباید بیشتر از ۲ مگابایت باشد.";
  }

  return "";
}

export function getPricingCap(orgLevel: OrgLevel) {
  return pricingCapsByLevel[orgLevel] ?? pricingCapsByLevel["کارشناس"];
}

export function pricingCapText(orgLevel: OrgLevel) {
  const cap = getPricingCap(orgLevel);
  return `سقف قیمت ${orgLevel}: ۳۰ دقیقه تا ${toman(cap[30])}، ۱ ساعت تا ${toman(cap[60])}. می‌توانی عدد کمتر انتخاب کنی.`;
}

export function moneyOrFree(value: number) {
  return value === 0 ? "رایگان" : toman(value);
}

export function updateDraftOrgLevel(draft: ProfileBuilderDraft, orgLevel: OrgLevel): ProfileBuilderDraft {
  const cap = getPricingCap(orgLevel);
  return {
    ...draft,
    orgLevel,
    price30: draft.freeHelp ? 0 : cap[30],
    price60: draft.freeHelp ? 0 : cap[60]
  };
}

export function setFreeHelp(draft: ProfileBuilderDraft, enabled: boolean, previousPaidPrices?: { price30: number; price60: number }): ProfileBuilderDraft {
  if (enabled) {
    return {
      ...draft,
      freeHelp: true,
      price30: 0,
      price60: 0
    };
  }

  const cap = getPricingCap(draft.orgLevel);
  return {
    ...draft,
    freeHelp: false,
    price30: Math.min(previousPaidPrices?.price30 ?? cap[30], cap[30]),
    price60: Math.min(previousPaidPrices?.price60 ?? cap[60], cap[60])
  };
}

export function validateProfileDraft(draft: ProfileBuilderDraft): ProfileValidationErrors {
  const errors: ProfileValidationErrors = {};
  const cap = getPricingCap(draft.orgLevel);

  if (!draft.displayName.trim() || draft.displayName.trim().length < 2) {
    errors.displayName = "نام نمایشی را کامل کن.";
  }

  if (!draft.role.trim() || draft.role.trim().length < 2) {
    errors.role = "نقش اصلی را وارد کن.";
  }

  if (draft.years < 0 || draft.years > 40 || Number.isNaN(draft.years)) {
    errors.years = "سال سابقه باید بین ۰ تا ۴۰ باشد.";
  }

  if (!draft.categories.length) {
    errors.categories = "حداقل یک دسته‌بندی انتخاب کن.";
  }

  if (!draft.companies.length) {
    errors.companies = "حداقل یک شرکت قبلی اضافه کن.";
  }

  if (!draft.languages.length) {
    errors.languages = "حداقل یک زبان انتخاب کن.";
  }

  if (!draft.summary.trim() || draft.summary.trim().length < 20) {
    errors.summary = "معرفی حرفه‌ای باید حداقل ۲۰ کاراکتر باشد.";
  }

  if (!draft.freeHelp) {
    if (draft.price30 < 0) {
      errors.price30 = "قیمت ۳۰ دقیقه نمی‌تواند منفی باشد.";
    }

    if (draft.price60 < 0) {
      errors.price60 = "قیمت ۱ ساعت نمی‌تواند منفی باشد.";
    }

    if (draft.price30 > cap[30]) {
      errors.price30 = `حداکثر قیمت ۳۰ دقیقه برای این رده ${toman(cap[30])} است.`;
    }

    if (draft.price60 > cap[60]) {
      errors.price60 = `حداکثر قیمت ۱ ساعت برای این رده ${toman(cap[60])} است.`;
    }

    if (draft.price60 < draft.price30) {
      errors.price60 = "قیمت ۱ ساعت نباید کمتر از ۳۰ دقیقه باشد.";
    }
  }

  return errors;
}

export function profileDraftIsValid(draft: ProfileBuilderDraft) {
  return Object.keys(validateProfileDraft(draft)).length === 0;
}

export function submitProfileForReview(draft: ProfileBuilderDraft) {
  if (!profileDraftIsValid(draft)) {
    return {
      status: "draft" as ExperienceProfileStatus,
      profile: null
    };
  }

  return {
    status: "pending_review" as ExperienceProfileStatus,
    profile: {
      name: draft.displayName,
      initials: draft.displayName.trim()[0] ?? "؟",
      roleFa: draft.role,
      orgLevel: draft.orgLevel,
      yearsOfExperience: draft.years,
      jobCategoriesFa: draft.categories,
      previousCompaniesFa: draft.companies,
      languages: draft.languages,
      professionalSummary: draft.summary,
      pricing: {
        30: draft.price30,
        60: draft.price60
      },
      freeHelp: draft.freeHelp,
      avatarUrl: draft.avatarUrl || undefined
    } satisfies MyExperienceProfile
  };
}

export function faSummaryCount(summary: string) {
  return `${formatter.format(summary.length)} / ۲۲۰`;
}

export function formatCsat(csat: number) {
  return toFaDecimal(csat);
}
