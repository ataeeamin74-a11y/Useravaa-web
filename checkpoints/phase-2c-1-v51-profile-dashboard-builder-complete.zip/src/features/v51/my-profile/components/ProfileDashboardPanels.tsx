import Link from "next/link";
import { V51LinkButton } from "@/features/v51/components/V51Button";
import { type MyProfileDashboardFixture } from "@/features/v51/data/my-profile";
import { formatter, toman } from "@/features/v51/data/profiles";
import { CsatValue, DashboardProfilePreview } from "./ProfilePreviewCard";
import styles from "./MyProfile.module.css";

type ProfileDashboardPanelsProps = {
  fixture: MyProfileDashboardFixture;
};

export function ProfileDashboardPanels({ fixture }: ProfileDashboardPanelsProps) {
  const showProfile = fixture.status !== "none";
  const showPerformance = fixture.status !== "none" && fixture.status !== "pending_review";

  return (
    <>
      <div className={styles.mainGrid}>
        <section className={styles.panel}>
          <div className={styles.sectionHead}>
            <div>
              <h2>پروفایل تجربه من</h2>
              <p>{showProfile ? "اطلاعاتی که در پروفایل تجربه‌ات نمایش داده می‌شود." : "هنوز پروفایل تجربه نداری."}</p>
            </div>
          </div>
          {showProfile ? (
            <>
              <DashboardProfilePreview profile={fixture.profile} />
              <div className={styles.actions}>
                <V51LinkButton href="/profiles/ali" tone="primary">
                  مشاهده پروفایل
                </V51LinkButton>
                <V51LinkButton href="/profile/build">ویرایش</V51LinkButton>
              </div>
            </>
          ) : (
            <>
              <div className={styles.empty}>برای دیده‌شدن در کشف تجربه‌ها، پروفایل تجربه بساز.</div>
              <div className={styles.actions}>
                <V51LinkButton href="/profile/build" tone="primary">
                  ساخت پروفایل تجربه
                </V51LinkButton>
              </div>
            </>
          )}
        </section>

        <section className={styles.panel}>
          <div className={styles.sectionHead}>
            <div>
              <h2>شبکه من</h2>
              <p>آدم‌هایی که دنبال کرده‌ای، ذخیره کرده‌ای یا تو را دنبال می‌کنند.</p>
            </div>
          </div>
          <div className={styles.networkGrid}>
            <Link href="/profile/network?tab=following" className={styles.networkStat}>
              <b>{formatter.format(fixture.network.following)}</b>
              <span>دنبال می‌کنم</span>
            </Link>
            <Link href="/profile/network?tab=saved" className={styles.networkStat}>
              <b>{formatter.format(fixture.network.saved)}</b>
              <span>ذخیره‌شده</span>
            </Link>
            <Link href="/profile/network?tab=followers" className={styles.networkStat}>
              <b>{formatter.format(fixture.network.followers)}</b>
              <span>دنبال‌کننده من</span>
            </Link>
          </div>
          <div className={styles.actions}>
            <V51LinkButton href="/profile/network" tone="primary">
              مدیریت شبکه من
            </V51LinkButton>
            <V51LinkButton href="/discover">کشف تجربه‌های بیشتر</V51LinkButton>
          </div>
        </section>
      </div>

      <div className={styles.mainGrid}>
        <section className={styles.panel}>
          {showPerformance ? (
            <>
              <div className={styles.sectionHead}>
                <div>
                  <h2>عملکرد تجربه</h2>
                  <p>خلاصه گفت‌وگوهای موفق و درآمد.</p>
                </div>
                <V51LinkButton href="/wallet">کیف پول و پرداخت‌ها</V51LinkButton>
              </div>
              <div className={styles.metrics}>
                <div className={styles.metric}>
                  <span>گفت‌وگوی موفق</span>
                  <b>{formatter.format(fixture.stats.successfulConversations)}</b>
                </div>
                <div className={styles.metric}>
                  <span>رضایت گفت‌وگوها</span>
                  <b>
                    <CsatValue value={fixture.stats.csat} />
                  </b>
                </div>
                <div className={styles.metric}>
                  <span>بازدید پروفایل</span>
                  <b>{formatter.format(fixture.stats.profileViews)}</b>
                </div>
                <div className={styles.metric}>
                  <span>قابل برداشت</span>
                  <b>{toman(fixture.stats.availableEarnings)}</b>
                </div>
              </div>
            </>
          ) : null}
        </section>

        <section className={styles.panel}>
          {showPerformance ? (
            <>
              <div className={styles.sectionHead}>
                <div>
                  <h2>بازخوردهای دریافتی</h2>
                  <p>بازخوردهایی که بعد از گفت‌وگوها برای تو ثبت شده‌اند.</p>
                </div>
              </div>
              <div className={styles.feedbackSummary}>
                <div>
                  <b>{formatter.format(fixture.feedbackCount)}</b>
                  <span>بازخورد</span>
                </div>
                <div>
                  <b>
                    <CsatValue value={fixture.stats.csat} />
                  </b>
                  <span>میانگین رضایت</span>
                </div>
              </div>
              <div className={styles.actions}>
                <V51LinkButton href="/profile/feedback" tone="primary">
                  دیدن بازخوردها
                </V51LinkButton>
              </div>
            </>
          ) : null}
        </section>
      </div>

      <section className={styles.panel}>
        <div className={styles.sectionHead}>
          <div>
            <h2>حساب و تنظیمات</h2>
            <p>اطلاعات حساب، تسویه و حریم خصوصی.</p>
          </div>
        </div>
        <div className={styles.settingsGrid}>
          <div className={styles.settingsItem}>
            <b>اطلاعات حساب</b>
            <span>
              {fixture.account.name} · {fixture.account.email}
            </span>
            <V51LinkButton href="/profile/settings">ویرایش اطلاعات حساب</V51LinkButton>
          </div>
          <div className={styles.settingsItem}>
            <b>اطلاعات تسویه</b>
            <span>{fixture.settlement.iban ?? "شماره شبا ثبت نشده است."}</span>
            <V51LinkButton href="/profile/settings">ثبت / ویرایش شبا</V51LinkButton>
          </div>
          <div className={styles.settingsItem}>
            <b>تنظیمات کامل</b>
            <span>اعلان‌ها، حریم خصوصی و وضعیت نمایش پروفایل.</span>
            <V51LinkButton href="/profile/settings">رفتن به تنظیمات</V51LinkButton>
          </div>
        </div>
      </section>
    </>
  );
}
