"use client";

import { useState } from "react";
import { transitionProfileStatus, type MyProfileDashboardFixture } from "@/features/v51/data/my-profile";
import { ProfileDashboardPanels } from "../components/ProfileDashboardPanels";
import { ProfileStatusCard } from "../components/ProfileStatusCard";
import styles from "../components/MyProfile.module.css";

type ProfileDashboardClientProps = {
  fixture: MyProfileDashboardFixture;
};

export function ProfileDashboardClient({ fixture }: ProfileDashboardClientProps) {
  const [status, setStatus] = useState(fixture.status);
  const [message, setMessage] = useState("");
  const dashboard = { ...fixture, status };

  const deactivateProfile = () => {
    const confirmed = typeof window === "undefined" ? true : window.confirm("پروفایل تجربه موقتاً غیرفعال شود؟");

    if (!confirmed) {
      return;
    }

    setStatus((current) => transitionProfileStatus(current, "deactivate_profile"));
    setMessage("پروفایل تجربه غیرفعال شد.");
  };

  const reactivateProfile = () => {
    setStatus((current) => transitionProfileStatus(current, "reactivate_requires_review"));
    setMessage("پروفایل تجربه برای بررسی دوباره ارسال شد.");
  };

  return (
    <>
      <ProfileStatusCard status={status} incomingRequests={fixture.incomingRequests} onDeactivate={deactivateProfile} onReactivate={reactivateProfile} />
      {message ? (
        <p className={styles.statusMessage} role="status" aria-live="polite">
          {message}
        </p>
      ) : null}
      <ProfileDashboardPanels fixture={dashboard} />
    </>
  );
}
