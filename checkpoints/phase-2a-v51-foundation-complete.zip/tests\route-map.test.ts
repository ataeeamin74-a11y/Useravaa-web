import { describe, expect, it } from "vitest";
import { appRoutes, getRouteById, getRouteIdByPathname } from "@/lib/routes";

describe("phase 1 route scaffold", () => {
  it("keeps the handoff route count in the scaffold", () => {
    expect(appRoutes).toHaveLength(16);
  });

  it("maps dynamic paths to their route ids", () => {
    expect(getRouteIdByPathname("/profiles/ali")).toBe("profileDetail");
    expect(getRouteIdByPathname("/conversations/conv_1/propose-times")).toBe("proposeTimes");
    expect(getRouteIdByPathname("/conversations/conv_1/select-time")).toBe("selectTime");
    expect(getRouteIdByPathname("/checkout/conv_1")).toBe("checkout");
  });

  it("preserves the V51 primary labels for top-level pages", () => {
    expect(getRouteById("discover").title).toBe("کشف تجربه‌ها");
    expect(getRouteById("conversations").title).toBe("گفت‌وگوها");
    expect(getRouteById("profile").title).toBe("پروفایل من");
    expect(getRouteById("wallet").title).toBe("کیف پول و پرداخت‌ها");
  });
});
