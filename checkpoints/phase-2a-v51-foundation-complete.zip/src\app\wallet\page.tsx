import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function WalletPage() {
  return <RoutePlaceholder routeId="wallet" />;
}
