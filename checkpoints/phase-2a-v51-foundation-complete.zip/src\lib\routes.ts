export type RouteId =
  | "discover"
  | "guide"
  | "profileDetail"
  | "requestNew"
  | "conversations"
  | "conversationDetail"
  | "proposeTimes"
  | "selectTime"
  | "checkout"
  | "profile"
  | "profileBuild"
  | "profileNetwork"
  | "profileFeedback"
  | "profileSettings"
  | "wallet"
  | "notifications";

export type AppRoute = {
  id: RouteId;
  href: string;
  title: string;
  summary: string;
  requiredApi: string;
  primaryActions: readonly string[];
  states: readonly string[];
};

export const appRoutes = [
  {
    id: "discover",
    href: "/discover",
    title: "کشف تجربه‌ها",
    summary: "لیست تجربه‌ها، فیلترها، مرتب‌سازی، ذخیره‌کردن و دنبال‌کردن مطابق V51.",
    requiredApi: "GET /api/profiles; POST/DELETE save/follow",
    primaryActions: ["search", "filter", "sort", "open_profile", "save", "follow"],
    states: ["loading", "empty", "error", "loaded", "no_results"]
  },
  {
    id: "guide",
    href: "/guide",
    title: "راهنما",
    summary: "راهنمای Useravaa با CTAهای رفتن به کشف تجربه‌ها و ساخت پروفایل تجربه.",
    requiredApi: "none",
    primaryActions: ["go_to_discover", "go_to_build_profile"],
    states: ["loaded"]
  },
  {
    id: "profileDetail",
    href: "/profiles/[profileId]",
    title: "پروفایل تجربه",
    summary: "نمای عمومی پروفایل تجربه، قیمت‌ها، CTA درخواست ۳۰ دقیقه و ۱ ساعت، ذخیره و دنبال‌کردن.",
    requiredApi: "GET /api/profiles/{profileId}; POST save/follow",
    primaryActions: ["request_30", "request_60", "save", "follow", "report"],
    states: ["loading", "error", "loaded", "inactive_profile"]
  },
  {
    id: "requestNew",
    href: "/requests/new",
    title: "درخواست گفت‌وگو",
    summary: "انتخاب مدت گفت‌وگو و ثبت درخواست اولیه برای پروفایل انتخاب‌شده.",
    requiredApi: "GET profile; POST /api/conversations",
    primaryActions: ["submit_request", "cancel"],
    states: ["loaded", "validation_error", "submitting"]
  },
  {
    id: "conversations",
    href: "/conversations",
    title: "گفت‌وگوها",
    summary: "درخواست‌های من، درخواست‌های دریافتی، گروه‌های نیازمند اقدام، پیگیری و تمام‌شده.",
    requiredApi: "GET /api/conversations",
    primaryActions: ["switch_sent_received", "primary_state_action", "open_detail"],
    states: ["loading", "empty", "error", "loaded", "needs_action", "tracking", "done"]
  },
  {
    id: "conversationDetail",
    href: "/conversations/[conversationId]",
    title: "جزئیات گفت‌وگو",
    summary: "نمای وضعیت محور گفت‌وگو، تایم‌لاین و CTAهای وابسته به state machine.",
    requiredApi: "GET conversation; state action endpoints",
    primaryActions: ["propose_times", "select_time", "pay", "cancel", "feedback"],
    states: ["loading", "error", "loaded", "state_specific"]
  },
  {
    id: "proposeTimes",
    href: "/conversations/[conversationId]/propose-times",
    title: "پیشنهاد زمان",
    summary: "انتخاب حداقل سه زمان پیشنهادی و ارسال زمان‌ها برای طرف مقابل.",
    requiredApi: "POST proposed-times",
    primaryActions: ["select_date", "select_time", "remove_time", "submit"],
    states: ["empty_selection", "invalid_count", "valid_selection", "submitting"]
  },
  {
    id: "selectTime",
    href: "/conversations/[conversationId]/select-time",
    title: "انتخاب زمان",
    summary: "انتخاب یکی از زمان‌های پیشنهادی برای ادامه مسیر نهایی‌سازی گفت‌وگو.",
    requiredApi: "POST select-time",
    primaryActions: ["select_proposed_time", "cancel"],
    states: ["loading", "no_options", "loaded", "submitting"]
  },
  {
    id: "checkout",
    href: "/checkout/[conversationId]",
    title: "پرداخت و نهایی‌سازی",
    summary: "مرور گفت‌وگو، بررسی موجودی کیف پول و مسیر پرداخت طبق رفتار V51.",
    requiredApi: "POST checkout; POST confirm payment",
    primaryActions: ["confirm_payment", "top_up", "cancel"],
    states: ["wallet_sufficient", "requires_gateway", "processing", "failed", "paid"]
  },
  {
    id: "profile",
    href: "/profile",
    title: "پروفایل من",
    summary: "داشبورد پروفایل تجربه، شبکه حرفه‌ای، بازخوردها، تنظیمات و کیف پول.",
    requiredApi: "GET me/profile/network/stats",
    primaryActions: ["edit_profile", "open_network", "open_feedback", "open_settings", "open_wallet"],
    states: ["no_profile", "pending_review", "needs_changes", "active", "inactive"]
  },
  {
    id: "profileBuild",
    href: "/profile/build",
    title: "ساخت پروفایل تجربه",
    summary: "رفتار profile builder شامل آواتار، پیش‌نویس، پیش‌نمایش و ارسال برای بررسی.",
    requiredApi: "POST draft; POST submit",
    primaryActions: ["upload_avatar", "save_draft", "preview", "submit_for_review"],
    states: ["draft", "invalid", "valid", "submitting", "pending_review"]
  },
  {
    id: "profileNetwork",
    href: "/profile/network",
    title: "شبکه من",
    summary: "تب‌های دنبال می‌کنم، ذخیره‌شده‌ها و دنبال‌کننده‌ها با جست‌وجو و فیلتر.",
    requiredApi: "GET /api/network",
    primaryActions: ["switch_tab", "search", "filter", "sort", "open_profile", "remove_save", "unfollow"],
    states: ["loading", "empty", "error", "loaded", "large_list"]
  },
  {
    id: "profileFeedback",
    href: "/profile/feedback",
    title: "بازخوردهای دریافتی",
    summary: "بازخوردهایی که بعد از گفت‌وگوها برای تجربه کاربر ثبت شده‌اند.",
    requiredApi: "GET /api/feedback/received",
    primaryActions: ["view_feedback"],
    states: ["loading", "empty", "error", "loaded"]
  },
  {
    id: "profileSettings",
    href: "/profile/settings",
    title: "تنظیمات حساب",
    summary: "تنظیمات حساب، اطلاعات تسویه، حریم خصوصی و اعلان‌ها.",
    requiredApi: "GET/PUT account; PUT settlement-info",
    primaryActions: ["edit_account", "edit_settlement", "privacy_toggle", "notification_toggle"],
    states: ["loaded", "validation_error", "saved"]
  },
  {
    id: "wallet",
    href: "/wallet",
    title: "کیف پول و پرداخت‌ها",
    summary: "موجودی، پرداخت‌ها، درآمد، اطلاعات تسویه و درخواست برداشت.",
    requiredApi: "GET wallet; top-up; payout",
    primaryActions: ["top_up", "request_payout", "edit_settlement", "filter_transactions"],
    states: ["loading", "empty", "error", "loaded", "missing_settlement_info"]
  },
  {
    id: "notifications",
    href: "/notifications",
    title: "اعلان‌ها",
    summary: "لیست اعلان‌ها، وضعیت خوانده‌نشده و باز کردن اعلان مرتبط با مسیر.",
    requiredApi: "GET notifications; POST read",
    primaryActions: ["open_notification", "mark_read"],
    states: ["loading", "empty", "error", "loaded"]
  }
] as const satisfies readonly AppRoute[];

export const mainNavigation = [
  { href: "/discover", label: "کشف تجربه‌ها", routeIds: ["discover"] },
  {
    href: "/conversations",
    label: "گفت‌وگوها",
    routeIds: ["conversations", "conversationDetail", "proposeTimes", "selectTime", "checkout"]
  },
  {
    href: "/profile",
    label: "پروفایل",
    routeIds: ["profile", "profileBuild", "profileNetwork", "profileFeedback", "profileSettings"]
  }
] as const;

export const utilityNavigation = [
  { href: "/guide", label: "راهنما", routeIds: ["guide"], variant: "link" },
  { href: "/notifications", label: "اعلان‌ها", routeIds: ["notifications"], variant: "pill", badge: "۳" },
  { href: "/wallet", label: "کیف پول", routeIds: ["wallet"], variant: "wallet" }
] as const;

export function getRouteById(routeId: RouteId): AppRoute {
  const route = appRoutes.find((item) => item.id === routeId);

  if (!route) {
    throw new Error(`Unknown route id: ${routeId}`);
  }

  return route;
}

export function getRouteIdByPathname(pathname: string): RouteId | undefined {
  if (pathname.startsWith("/profiles/")) {
    return "profileDetail";
  }

  if (pathname === "/requests/new") {
    return "requestNew";
  }

  if (pathname.startsWith("/conversations/") && pathname.endsWith("/propose-times")) {
    return "proposeTimes";
  }

  if (pathname.startsWith("/conversations/") && pathname.endsWith("/select-time")) {
    return "selectTime";
  }

  if (pathname.startsWith("/conversations/")) {
    return "conversationDetail";
  }

  if (pathname.startsWith("/checkout/")) {
    return "checkout";
  }

  const exactRoute = appRoutes.find((route) => route.href === pathname);
  return exactRoute?.id;
}
