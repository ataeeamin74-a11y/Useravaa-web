import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function ProfileSettingsPage() {
  return <RoutePlaceholder routeId="profileSettings" />;
}
