import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function ConversationsPage() {
  return <RoutePlaceholder routeId="conversations" />;
}
