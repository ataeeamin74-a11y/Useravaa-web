import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function SelectTimePage() {
  return <RoutePlaceholder routeId="selectTime" />;
}
