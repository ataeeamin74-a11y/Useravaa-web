import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function ConversationDetailPage() {
  return <RoutePlaceholder routeId="conversationDetail" />;
}
