import { V51LinkButton } from "@/features/v51/components/V51Button";
import { formatter, toFaDecimal, toman, type ExperienceProfileFixture } from "@/features/v51/data/profiles";
import styles from "./ProfileDetailPage.module.css";

type ProfileDetailPageProps = Readonly<{
  profile: ExperienceProfileFixture;
}>;

export function ProfileDetailPage({ profile }: ProfileDetailPageProps) {
  return (
    <section className={styles.layout}>
      <div>
        <div className={styles.heroProfile}>
          <div className={styles.profileAvatar}>{profile.initials}</div>
          <div>
            <h1 className={styles.profileName}>{profile.name}</h1>
            <div className={styles.role}>{profile.roleFa}</div>
            <div className={styles.badges}>
              <span className={`${styles.chip} ${styles.level}`}>{profile.orgLevel}</span>
              <span className={styles.chip}>{formatter.format(profile.yearsOfExperience)} سال سابقه</span>
              {profile.csat ? (
                <span className={`${styles.chip} ${styles.csat}`}>
                  <span className={styles.star}>★</span>
                  {toFaDecimal(profile.csat)}
                </span>
              ) : null}
            </div>
          </div>
        </div>

        <div className={styles.panel}>
          <h2>معرفی حرفه‌ای</h2>
          <p>{profile.professionalSummary}</p>
        </div>

        <div className={styles.panel}>
          <h2>اطلاعات حرفه‌ای</h2>
          <div className={styles.row}>
            <span className={styles.k}>رده سازمانی</span>
            <span className={styles.v}>{profile.orgLevel}</span>
          </div>
          <div className={styles.row}>
            <span className={styles.k}>سابقه کار</span>
            <span className={styles.v}>{formatter.format(profile.yearsOfExperience)} سال</span>
          </div>
          <div className={styles.row}>
            <span className={styles.k}>دسته‌بندی شغلی</span>
            <span className={styles.v}>{profile.jobCategoriesFa.join("، ")}</span>
          </div>
          <div className={styles.row}>
            <span className={styles.k}>شرکت‌های قبلی</span>
            <span className={styles.v}>{profile.previousCompaniesFa.length ? profile.previousCompaniesFa.join("، ") : "شرکت قبلی ثبت نشده است"}</span>
          </div>
          <div className={styles.row}>
            <span className={styles.k}>زبان گفت‌وگو</span>
            <span className={styles.v}>{profile.languages.join("، ")}</span>
          </div>
        </div>

        <div className={styles.panel}>
          <h2>رضایت گفت‌وگوها</h2>
          <p>{profile.csat ? `★ ${toFaDecimal(profile.csat)} از ۵` : "هنوز بازخوردی ثبت نشده است."}</p>
          <p>{profile.review}</p>
        </div>
      </div>

      <aside className={`${styles.panel} ${styles.sticky}`}>
        <h2>درخواست گفت‌وگو</h2>
        <p className={styles.muted}>زمان‌های آزاد در پروفایل نمایش داده نمی‌شود. بعد از ثبت درخواست، ارائه‌دهنده حداقل سه زمان پیشنهادی اعلام می‌کند.</p>
        <div className={styles.priceGrid}>
          <div className={styles.priceCard}>
            <span>۳۰ دقیقه</span>
            <b>{toman(profile.pricing[30])}</b>
          </div>
          <div className={styles.priceCard}>
            <span>۱ ساعت</span>
            <b>{toman(profile.pricing[60])}</b>
          </div>
        </div>
        <V51LinkButton href={`/requests/new?profileId=${profile.id}&duration=30`} tone="primary" full className={styles.requestButton}>
          درخواست گفت‌وگو
        </V51LinkButton>
      </aside>
    </section>
  );
}
