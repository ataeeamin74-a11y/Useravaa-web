import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function ProfileFeedbackPage() {
  return <RoutePlaceholder routeId="profileFeedback" />;
}
