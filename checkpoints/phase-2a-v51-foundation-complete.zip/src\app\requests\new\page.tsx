import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function NewRequestPage() {
  return <RoutePlaceholder routeId="requestNew" />;
}
