import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function ProfileNetworkPage() {
  return <RoutePlaceholder routeId="profileNetwork" />;
}
