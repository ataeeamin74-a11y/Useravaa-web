import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function CheckoutPage() {
  return <RoutePlaceholder routeId="checkout" />;
}
