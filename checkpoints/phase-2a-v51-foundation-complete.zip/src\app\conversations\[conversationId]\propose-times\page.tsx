import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function ProposeTimesPage() {
  return <RoutePlaceholder routeId="proposeTimes" />;
}
