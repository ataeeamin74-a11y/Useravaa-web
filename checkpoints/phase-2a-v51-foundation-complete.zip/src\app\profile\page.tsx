import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function ProfilePage() {
  return <RoutePlaceholder routeId="profile" />;
}
