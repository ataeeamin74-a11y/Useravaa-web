"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { getRouteIdByPathname, mainNavigation, utilityNavigation } from "@/lib/routes";
import styles from "./Header.module.css";

function joinClasses(...classes: Array<string | false | undefined>) {
  return classes.filter(Boolean).join(" ");
}

export function Header() {
  const pathname = usePathname();
  const activeRouteId = getRouteIdByPathname(pathname);

  const routeIsActive = (routeIds: readonly string[]) => {
    return activeRouteId ? routeIds.includes(activeRouteId) : false;
  };

  return (
    <header className={styles.topbar}>
      <Link href="/discover" className={styles.brand} aria-label="Useravaa">
        <span className={styles.mark}>UA</span>
        <span className={styles.brandName}>Useravaa</span>
      </Link>

      <nav className={styles.mainNav} aria-label="ناوبری اصلی">
        {mainNavigation.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={joinClasses(styles.mainNavLink, routeIsActive(item.routeIds) && styles.active)}
            aria-current={routeIsActive(item.routeIds) ? "page" : undefined}
          >
            {item.label}
          </Link>
        ))}
      </nav>

      <nav className={styles.utilities} aria-label="ابزارهای حساب">
        {utilityNavigation.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={joinClasses(
              styles.utilityLink,
              item.variant === "link" && styles.utilityPlain,
              item.variant === "pill" && styles.utilityPill,
              item.variant === "wallet" && styles.utilityWallet,
              routeIsActive(item.routeIds) && styles.active
            )}
            aria-current={routeIsActive(item.routeIds) ? "page" : undefined}
            aria-label={item.label}
          >
            <span>{item.label}</span>
            {"badge" in item ? <span className={styles.badge}>{item.badge}</span> : null}
          </Link>
        ))}
      </nav>
    </header>
  );
}
