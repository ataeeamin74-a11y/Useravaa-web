import { RoutePlaceholder } from "@/components/route-placeholder/RoutePlaceholder";

export default function NotificationsPage() {
  return <RoutePlaceholder routeId="notifications" />;
}
