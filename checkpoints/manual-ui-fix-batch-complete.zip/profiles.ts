export type DurationPricing = {
  30: number | null;
  60: number | null;
};

export type ExperienceProfileFixture = {
  id: string;
  name: string;
  initials: string;
  roleFa: string;
  orgLevel: string;
  yearsOfExperience: number;
  csat: number | null;
  followers: number;
  conversations: number;
  lastActiveDays: number;
  previousCompaniesFa: string[];
  jobCategoriesFa: string[];
  professionalSummary: string;
  languages: string[];
  pricing: DurationPricing;
  review: string;
  reviewAuthor: {
    name: string;
    role: string;
    company?: string;
  };
  isFollowing: boolean;
  isSaved: boolean;
};

export const profiles = [
  {
    id: "ali",
    name: "علی ر.",
    initials: "ع",
    roleFa: "مدیر محصول",
    orgLevel: "مدیر میانی",
    yearsOfExperience: 8,
    csat: 4.8,
    followers: 186,
    conversations: 42,
    lastActiveDays: 1,
    previousCompaniesFa: ["اسنپ", "دیجی‌کالا"],
    jobCategoriesFa: ["محصول", "هوش تجاری", "تحلیل داده"],
    professionalSummary: "تجربه در تیم‌های محصول و تحلیل داده، با تمرکز بر تصمیم‌سازی محصولی.",
    languages: ["فارسی"],
    pricing: { 30: 1000000, 60: 1800000 },
    review: "گفت‌وگو دقیق، کاربردی و متناسب با تجربه کاری‌اش بود.",
    reviewAuthor: { name: "مریم ک.", role: "مدیر محصول", company: "دیوار" },
    isFollowing: false,
    isSaved: false
  },
  {
    id: "sara",
    name: "سارا م.",
    initials: "س",
    roleFa: "طراح محصول",
    orgLevel: "کارشناس ارشد",
    yearsOfExperience: 6,
    csat: 4.7,
    followers: 143,
    conversations: 36,
    lastActiveDays: 3,
    previousCompaniesFa: ["کافه‌بازار", "دیوار"],
    jobCategoriesFa: ["طراحی محصول", "تجربه کاربر", "پورتفولیو"],
    professionalSummary: "تجربه طراحی محصول، طراحی تجربه کاربر، ساخت پورتفولیو و همکاری با تیم‌های محصول.",
    languages: ["فارسی", "انگلیسی"],
    pricing: { 30: 500000, 60: 900000 },
    review: "درک خوبی از فضای طراحی محصول و همکاری با تیم‌های محصول داشت.",
    reviewAuthor: { name: "نیما الف.", role: "طراح محصول", company: "اسنپ" },
    isFollowing: false,
    isSaved: false
  },
  {
    id: "nazanin",
    name: "نازنین ک.",
    initials: "ن",
    roleFa: "راهبر هوش تجاری",
    orgLevel: "مدیر ارشد",
    yearsOfExperience: 10,
    csat: 4.9,
    followers: 212,
    conversations: 58,
    lastActiveDays: 0,
    previousCompaniesFa: ["دیجی‌کالا", "علی‌بابا"],
    jobCategoriesFa: ["هوش تجاری", "تحلیل داده", "داشبورد"],
    professionalSummary: "تجربه کار با داده، داشبوردهای تصمیم‌ساز و مدیریت فعالیت‌های BI.",
    languages: ["فارسی", "انگلیسی"],
    pricing: { 30: 1000000, 60: 1800000 },
    review: "تجربه‌اش در BI و تحلیل داده برای تصمیم‌گیری شغلی روشن‌کننده بود.",
    reviewAuthor: { name: "سارا ب.", role: "تحلیل‌گر داده", company: "کافه‌بازار" },
    isFollowing: false,
    isSaved: false
  },
  {
    id: "mina",
    name: "مینا پ.",
    initials: "م",
    roleFa: "کارشناس رشد",
    orgLevel: "کارشناس",
    yearsOfExperience: 4,
    csat: 4.6,
    followers: 98,
    conversations: 21,
    lastActiveDays: 6,
    previousCompaniesFa: ["اسنپ", "تپسی"],
    jobCategoriesFa: ["رشد", "مارکتینگ", "جذب کاربر"],
    professionalSummary: "تجربه در Growth Marketing، کمپین‌های رشد، تحلیل داده و قیف جذب کاربر.",
    languages: ["فارسی"],
    pricing: { 30: 300000, 60: 500000 },
    review: "شناخت خوبی از Growth، کمپین و کار با داده داشت.",
    reviewAuthor: { name: "آرش ن.", role: "کارشناس رشد", company: "تپسی" },
    isFollowing: false,
    isSaved: false
  },
  {
    id: "reza",
    name: "رضا الف.",
    initials: "ر",
    roleFa: "مدیر مهندسی",
    orgLevel: "مدیر ارشد",
    yearsOfExperience: 15,
    csat: 4.9,
    followers: 304,
    conversations: 74,
    lastActiveDays: 2,
    previousCompaniesFa: ["دیجی‌کالا", "اسنپ"],
    jobCategoriesFa: ["مهندسی", "رهبری تیم", "محصول"],
    professionalSummary: "تجربه مدیریت تیم‌های فنی، همکاری با محصول و ساختاردهی تیم‌های رشدپذیر.",
    languages: ["فارسی", "انگلیسی"],
    pricing: { 30: 1000000, 60: 1800000 },
    review: "درک خوبی از رشد تیم فنی و تصمیم‌های مدیریتی داشت.",
    reviewAuthor: { name: "مهسا ک.", role: "مهندس نرم‌افزار", company: "دیجی‌کالا" },
    isFollowing: false,
    isSaved: false
  },
  {
    id: "niloofar",
    name: "نیلوفر ج.",
    initials: "ن",
    roleFa: "شریک منابع انسانی",
    orgLevel: "مدیر میانی",
    yearsOfExperience: 2,
    csat: null,
    followers: 76,
    conversations: 0,
    lastActiveDays: 8,
    previousCompaniesFa: ["تپسی", "دیوار"],
    jobCategoriesFa: ["منابع انسانی", "افراد", "مسیر شغلی", "مصاحبه"],
    professionalSummary: "تجربه در مسیرهای رشد شغلی، گفت‌وگوهای عملکردی و همکاری با تیم‌های کسب‌وکار.",
    languages: ["فارسی"],
    pricing: { 30: 1000000, 60: 1800000 },
    review: "هنوز بازخوردی ثبت نشده است.",
    reviewAuthor: { name: "کاربر Useravaa", role: "درخواست‌دهنده گفت‌وگو" },
    isFollowing: false,
    isSaved: false
  },
  {
    id: "hamid",
    name: "حمید ص.",
    initials: "ح",
    roleFa: "تحلیل‌گر داده",
    orgLevel: "کارشناس",
    yearsOfExperience: 1,
    csat: null,
    followers: 18,
    conversations: 0,
    lastActiveDays: 12,
    previousCompaniesFa: [],
    jobCategoriesFa: ["تحلیل داده", "داشبورد", "SQL", "گزارش‌سازی"],
    professionalSummary: "تجربه شروع مسیر در تحلیل داده، گزارش‌سازی و ساخت داشبوردهای عملیاتی.",
    languages: ["فارسی"],
    pricing: { 30: 300000, 60: 500000 },
    review: "هنوز بازخوردی ثبت نشده است.",
    reviewAuthor: { name: "کاربر Useravaa", role: "درخواست‌دهنده گفت‌وگو" },
    isFollowing: false,
    isSaved: false
  }
] as const satisfies readonly ExperienceProfileFixture[];

export type DiscoveryState = "ready" | "loading" | "error";
export type ExperienceRange = "" | "0-2" | "3-5" | "6-9" | "10-14" | "15+";
export type SortOption = "relevant" | "experience_desc" | "csat_desc" | "recent_activity";

export const formatter = new Intl.NumberFormat("fa-IR");

export function toman(value: number | null) {
  return value == null ? "نیاز به تعیین" : `${formatter.format(value)} تومان`;
}

export function toFaDecimal(value: number) {
  return String(value).replace(".", "٫");
}

export function uniqueValues(values: readonly string[]) {
  return Array.from(new Set(values));
}

export const roleOptions = uniqueValues(profiles.map((profile) => profile.roleFa));
export const categoryOptions = uniqueValues(profiles.flatMap((profile) => profile.jobCategoriesFa));
export const companyOptions = uniqueValues(profiles.flatMap((profile) => profile.previousCompaniesFa));

export function yearsInRange(years: number, range: ExperienceRange) {
  if (!range) {
    return true;
  }

  if (range === "0-2") {
    return years >= 0 && years <= 2;
  }

  if (range === "3-5") {
    return years >= 3 && years <= 5;
  }

  if (range === "6-9") {
    return years >= 6 && years <= 9;
  }

  if (range === "10-14") {
    return years >= 10 && years <= 14;
  }

  return years >= 15;
}

export function getProfileById(profileId: string) {
  return profiles.find((profile) => profile.id === profileId);
}

export function getRequestHref(profileId: string, duration: 30 | 60) {
  return `/requests/new?profileId=${profileId}&duration=${duration}`;
}

export function toggleProfileIdSelection(selectedIds: ReadonlySet<string>, profileId: string) {
  const next = new Set(selectedIds);
  if (next.has(profileId)) {
    next.delete(profileId);
  } else {
    next.add(profileId);
  }
  return next;
}
